<?php
if(!isset($seguranca)){
    exit;
}
$sendCadastraUser = filter_input(INPUT_POST, 'sendCadastraUser', FILTER_DEFAULT);
//Verificar se a variavel possui um valor
if($sendCadastraUser){
    $nome_completo  = filter_input(INPUT_POST, 'nome_completo', FILTER_DEFAULT);
    $email          = filter_input(INPUT_POST, 'email', FILTER_DEFAULT); 
    $usuario        = filter_input(INPUT_POST, 'usuario', FILTER_DEFAULT); 
    $senha          = filter_input(INPUT_POST, 'senha', FILTER_DEFAULT);
    $senha_crip     = password_hash($senha, PASSWORD_DEFAULT);
    $unidade        = filter_input(INPUT_POST, 'unidade', FILTER_DEFAULT); 
    $status         = filter_input(INPUT_POST, 'status', FILTER_DEFAULT);
    $perfil_acesso  = filter_input(INPUT_POST, 'perfil_acesso', FILTER_DEFAULT); 
    $anotacao       = filter_input(INPUT_POST, 'anotacao', FILTER_DEFAULT);
    $cargo          = filter_input(INPUT_POST, 'cargo', FILTER_DEFAULT);     
    //Validar campo senha e retirar os espaços em branco
    $senha_sem_espaco = str_replace(" ", "", $senha_crip);
    //Verificar se o usuário esta cadastrado no banco de dados
    $verifica_registro_user = "SELECT * FROM usuarios WHERE login_user = '$usuario' ";
    $query_verifica_registro_user = mysqli_query($conn, $verifica_registro_user);
    //Verificar se o email esta cadastrado no banco de dados
    $verifica_registro_email = "SELECT * FROM usuarios WHERE email_user = '$email' ";
    $query_verifica_registro_email = mysqli_query($conn, $verifica_registro_email);
    //Verificar a quantidade de usuários disponiveis
    $cons_contrato = "SELECT 
        c.qtd_usuarios_liberados AS usuarios_permitidos,
        COUNT(u.id_user) AS total_cadastrados
      FROM 
        contrato_sistema c
      INNER JOIN usuarios u
      ON u.contrato_sistema_id = c.idcontratosistema
      WHERE c.idcontratosistema = '{$_SESSION['contratoID']}'
      HAVING COUNT(u.id_user) < c.qtd_usuarios_liberados";
      $query_cons_contrato = mysqli_query($conn, $cons_contrato);
    //Validar a quantidade de caracteres no campo senha    
    if((strlen($senha_sem_espaco)) < 6){
        $_SESSION['msg'] = '
            <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-sm">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <p class="text-center">Senha deve ter no minimo 6 caracteres.</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                    </div>
                  </div>
                </div>
            </div>
        ';
    $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
    echo '<script> location.replace("'.$url_destino.'"); </script>';
    }elseif(($query_verifica_registro_user) AND ($query_verifica_registro_user->num_rows !=0)){
        $_SESSION['msg'] = '
            <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-sm">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <p class="text-center">Usuário já cadastrado.</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                    </div>
                  </div>
                </div>
            </div>
        ';
        $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
        echo '<script> location.replace("'.$url_destino.'"); </script>';
    }elseif(($query_verifica_registro_email) AND ($query_verifica_registro_email->num_rows !=0)){
        $_SESSION['msg'] = '
            <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-sm">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <p class="text-center">E-mail já cadastrado.</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                    </div>
                  </div>
                </div>
            </div>
        ';
        $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
        echo '<script> location.replace("'.$url_destino.'"); </script>';
    }else{
        //token de acesso
        $bytes = random_bytes(32);
        $token = hash('sha256', $bytes);
        if ($_SESSION['contratoUSER'] == null) {
          $cad_user = "INSERT INTO usuarios 
            (nome_user, email_user, login_user, senha_user, token, niveis_acesso_id, situacoes_usuario_id, cargo_id, unidade_id, usuario_id, anotacao, criado_user, ult_token) 
            VALUES 
            ('$nome_completo', '$email', '$usuario', '$senha_crip', '$token', '$perfil_acesso', '$status', '$cargo', '$unidade', '{$_SESSION['usuarioID']}', '$anotacao', NOW(), NOW())";
          $query_cad_user = mysqli_query($conn, $cad_user);
          //verificar se foi salvo no banco de dados
          if(mysqli_insert_id($conn)){
              //pegar o id do usuario cadastrado
              $ult_id_usuario = mysqli_insert_id($conn);
              //salvar o historico de alteração de senha
              $cad_hist_senha = "INSERT INTO hist_senha (usuario_id, operador, evento_senha_id, created_hist_senha) VALUES ('$ult_id_usuario', '{$_SESSION['usuarioID']}', '3', NOW())";
              $query_cad_hist_senha = mysqli_query($conn, $cad_hist_senha);
              //mensagem
              if(mysqli_affected_rows($conn) != 0){
                if (isset($_POST["sendEmail"]) && $_POST["sendEmail"] == "on") {
                  sendEmail($conn, $ult_id_usuario, $senha, 1);
                }
                  $_SESSION['msg'] = '
                      <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered modal-sm">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Sucesso!</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p class="text-center">Conta do usuário criada</p>
                                <p class="text-left">
                                  Login de acesso: '.$usuario.' <br />
                                  Senha de acesso: '.$senha.'
                                </p>
                                <p class="text-left">
                                  Solicitar ao usuário que altere a senha no próximo login.
                                </p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                              </div>
                            </div>
                          </div>
                      </div>
                  ';
                  $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
                  echo '<script> location.replace("'.$url_destino.'"); </script>';
              }else{
                $msg_erro = mysqli_error($conn);
                  $_SESSION['msg'] = '
                      <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered modal-sm">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p class="text-center">Historico de criação de senha não registrado <br> '.$msg_erro.'</p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                              </div>
                            </div>
                          </div>
                      </div>
                  ';
                  $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
                  echo '<script> location.replace("'.$url_destino.'"); </script>';
              }            
          }else{
            $msg_erro = mysqli_error($conn);
              $_SESSION['msg'] = '
                  <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <p class="text-center">Conta de usuário não registrada <br> '.$msg_erro.'</p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                          </div>
                        </div>
                      </div>
                  </div>
              ';
              $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
              echo '<script> location.replace("'.$url_destino.'"); </script>';
          }
        }else{
          if(($query_cons_contrato) AND ($query_cons_contrato->num_rows != 0)){
            //Instrução para salvar no banco de dados
            $cad_user = "INSERT INTO usuarios 
              (nome_user, email_user, login_user, senha_user, token, niveis_acesso_id, situacoes_usuario_id, cargo_id, unidade_id, usuario_id, contrato_sistema_id, anotacao, criado_user, ult_token) 
              VALUES 
              ('$nome_completo', '$email', '$usuario', '$senha_crip', '$token', '$perfil_acesso', '$status', '$cargo', '$unidade', '{$_SESSION['usuarioID']}', '{$_SESSION['contratoID']}', '$anotacao', NOW(), NOW())";
            $query_cad_user = mysqli_query($conn, $cad_user);
            //verificar se foi salvo no banco de dados
            if(mysqli_insert_id($conn)){
                //pegar o id do usuario cadastrado
                $ult_id_usuario = mysqli_insert_id($conn);
                //salvar o historico de alteração de senha
                $cad_hist_senha = "INSERT INTO hist_senha (usuario_id, operador, evento_senha_id, created_hist_senha) VALUES ('$ult_id_usuario', '{$_SESSION['usuarioID']}', '3', NOW())";
                $query_cad_hist_senha = mysqli_query($conn, $cad_hist_senha);
                //mensagem
                if(mysqli_affected_rows($conn) != 0){
                    $_SESSION['msg'] = '
                        <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-sm">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Sucesso!</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <p class="text-center">Conta do usuário criada</p>
                                  <p class="text-left">
                                    Login de acesso: '.$usuario.' <br />
                                    Senha de acesso: '.$senha.'
                                  </p>
                                  <p class="text-left">
                                    Solicitar ao usuário que altere a senha no próximo login.
                                  </p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                                </div>
                              </div>
                            </div>
                        </div>
                    ';
                    $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
                    echo '<script> location.replace("'.$url_destino.'"); </script>';
                }else{
                  $msg_erro = mysqli_error($conn);
                    $_SESSION['msg'] = '
                        <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-sm">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <p class="text-center">Historico de criação de senha não registrado <br> '.$msg_erro.'</p>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                                </div>
                              </div>
                            </div>
                        </div>
                    ';
                    $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
                    echo '<script> location.replace("'.$url_destino.'"); </script>';
                }            
            }else{
              $msg_erro = mysqli_error($conn);
                $_SESSION['msg'] = '
                    <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-sm">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <p class="text-center">Conta de usuário não registrada <br> '.$msg_erro.'</p>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                            </div>
                          </div>
                        </div>
                    </div>
                ';
                $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
                echo '<script> location.replace("'.$url_destino.'"); </script>';
            }
          }else{
            $_SESSION['msg'] = '
                <div class="modal fade" id="procmsg" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="staticBackdropLabel">Atenção!</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <p class="text-center">Limite de usuários excedido para este contrato.</p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                        </div>
                      </div>
                    </div>
                </div>
            ';
            $url_destino = pg."/pages/modulo/controle_de_acesso/cadastrar/cad_usuario";
            echo '<script> location.replace("'.$url_destino.'"); </script>';
          } 
        }        
    }    
} else {
    $url_destino = pg."/pages/modulo/404/404";
    echo '<script> location.replace("'.$url_destino.'"); </script>';
}

