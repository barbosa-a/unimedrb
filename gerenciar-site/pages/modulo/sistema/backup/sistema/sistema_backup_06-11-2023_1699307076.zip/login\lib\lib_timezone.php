<?php

    date_default_timezone_set('America/Rio_Branco');
?>
