<?php
    if (!isset($seguranca)) {
        exit;
    }
    if (isset($_SESSION['msg'])) {
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
    }
    //recuperar dados vindo da url
    $usuario = filter_input(INPUT_GET, 'usuario', FILTER_SANITIZE_NUMBER_INT);
    //Consultar usuario
    $cons_usuario = "SELECT * FROM usuarios WHERE id_user = '$usuario' LIMIT 1 ";
    $query_cons_usuario = mysqli_query($conn, $cons_usuario);
    $row_usuario = mysqli_fetch_array($query_cons_usuario);
?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"><?php echo NomePagina($_SESSION['usuarioNIVEL'], filter_input(INPUT_GET, 'url', FILTER_SANITIZE_STRING), $conn); ?></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item">Página inicial</li>
          <li class="breadcrumb-item active"><a href="<?php echo pg; ?>/pages/modulo/home/home">Inicio</a></li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="card card-primary card-outline">
          <div class="card-header">
            <h5 class="m-0">Editar dados do usuário</h5>
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo pg; ?>/pages/modulo/controle_de_acesso/editar/processa/proc_edit_usuario" enctype="multipart/form-data">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="Nome completo do usuário">Nome completo</label>
                            <input type="text" class="form-control" name="nome_completo" placeholder="Nome completo" required="" autofocus="" value="<?php echo $row_usuario['nome_user']; ?>" oninput="upperCase(event)">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="E-mail do usuário">E-mail</label>
                            <input type="email" class="form-control" name="email" placeholder="E-mail" required="" value="<?php echo $row_usuario['email_user']; ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-6">
                            <label for="Usuário de acesso ao sistema">Usuário</label>
                            <input type="text" class="form-control" name="login_user" placeholder="Nome de usuário" required="" value="<?php echo $row_usuario['login_user']; ?>">
                        </div>
                        <div class="form-group col-6">
                            <label for="Locação ou função do usuário">Cargo</label>
                            <select name="cargo" class="form-control" required="">
                                <option value="">Selecione...</option>
                                <?php echo ListarCargosUsuario($row_usuario['cargo_id'], $conn); ?> 
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="Local de trabalho do usuário">Unidade</label>
                            <select name="unidade" class="form-control" required="">
                                <option value="">Selecione...</option>
                                <?php echo ListarUnidadesUsuario($row_usuario['unidade_id'], $conn); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="Status do usuário">Status</label>
                            <select name="status" class="form-control" required="">
                                <option value="">Selecione...</option>
                                <?php echo ListarStatusUsuario($row_usuario['situacoes_usuario_id'], $conn); ?>  
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="Perfil de acesso do usuário">Perfil de acesso</label>
                            <select name="perfil_acesso" class="form-control" required="">
                                <option value="">Selecione...</option>
                                <?php echo ListarPerfilUsuario($_SESSION['usuarioORDEM'], $row_usuario['niveis_acesso_id'], $conn); ?>  
                            </select>
                        </div>                        
                    </div>
                    <div class="form-row">
                        <div class="form-group col-12">
                            <label for="Descrição">Descrição</label>
                            <textarea name="anotacao" class="form-control" placeholder="Observação do usuário" rows="3"><?php echo $row_usuario['anotacao']; ?></textarea>
                        </div>
                    </div>
                    <input type="hidden" name="usuario" value="<?php echo $row_usuario['id_user']; ?>" />
                    <input type="submit" class="btn btn-primary" value="Salvar" name="sendEditarUser">
                    <a href="<?php echo pg; ?>/pages/modulo/controle_de_acesso/controle_de_acesso">
                        <button type="button" class="btn btn-secondary">Voltar</button>
                    </a>
                    <a href="<?php echo pg; ?>/pages/modulo/controle_de_acesso/editar/edit_senha_usuario?usuario=<?php echo $usuario; ?>">
                        <input type="button" class="btn btn-secondary" value="Redefinir senha" name="redefinir_senha" />
                    </a>
                </form>
            
          </div>
        </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content -->