<?php  
	session_start();
	//segurança do ADM
    $seguranca = true;   
    include_once("../../../../config/config.php"); 
	include_once("../../../../config/conexao.php");
	include_once("../../../../lib/lib_funcoes.php");
	include_once("../../../../lib/lib_botoes.php");

	$dados_usuario = filter_input(INPUT_GET, 'dados_usuario', FILTER_SANITIZE_STRING);
	if (!empty($dados_usuario)) {
		//Cnsultar usuário atraves do campo pesquisa
	    if(($_SESSION['usuarioNIVEL'] == 1) OR ($_SESSION['contratoUSER'] == null)){
	        $cons_usuario = "SELECT * FROM usuarios u
	            INNER JOIN situacoes_usuarios s on s.id_situacao = u.situacoes_usuario_id 
	            WHERE nome_user LIKE '%$dados_usuario%' ";
	    } else {
	        $cons_usuario = "SELECT * FROM usuarios u
	            INNER JOIN situacoes_usuarios s on s.id_situacao = u.situacoes_usuario_id 
	            WHERE u.niveis_acesso_id <> 1 AND (u.contrato_sistema_id = '".$_SESSION['contratoUSER']."' OR u.contrato_sistema_id IS NOT NULL) AND nome_user LIKE '%$dados_usuario%' ";
	    } 
	    $query_cons_usuario = mysqli_query($conn, $cons_usuario);
	    if (($query_cons_usuario) AND ($query_cons_usuario->num_rows != 0)) {
	    	$row_total = mysqli_num_rows($query_cons_usuario);
		        echo '
		            <div class="row ">
		                <div class="col-6">
		                    Resultado(s) de busca: "' . $dados_usuario . '"
		                </div>
		                <div class="col-6 text-right">
		                    ' . $row_total . ' registro(s) encontrado.
		                </div>                                        
		            </div>
		            <div class="table-responsive">
		                <table class="table ">
		                    <thead>
		                        <tr>
		                            <th>Nome</th>
		                            <th>Nome de usuário</th>
		                            <th>Status</th>
		                            <th class="d-none d-md-table-cell">Data</th>
		                            <th>Ação</th>
		                        </tr>
		                    </thead>
		                    <tbody>
		            ';
		        while ($row_usuario = mysqli_fetch_array($query_cons_usuario)) { ?>
		          <tr>
		            <td><?php echo $row_usuario['nome_user']; ?></td>
		            <td><?php echo $row_usuario['login_user']; ?></td>
		            <td class="<?php echo $row_usuario['cor_situacao']; ?>"><?php echo $row_usuario['nome_situacao']; ?></td>
		            <td class="d-none d-md-table-cell"><?php echo date('d/m/Y', strtotime($row_usuario['criado_user'])); ?></td>
		            <td class="table-action">
		              <?php if ($botao_edit_user) { ?>
		                <a href="<?php echo pg; ?>/pages/modulo/controle_de_acesso/editar/edit_usuario?usuario=<?php echo $row_usuario['id_user']; ?>">
		                  <i class="align-middle fa fa-pencil-square-o mr-2"></i>
		                </a>
		              <?php }else{ ?>
		                
		              <?php } ?>
		              <?php if ($botao_apagar_user) { ?>
		                <a href="<?php echo pg; ?>/pages/modulo/controle_de_acesso/apagar/proc_del_usuario?usuario=<?php echo $row_usuario['id_user']; ?>">
		                  <i class="align-middle fa fa-trash"></i>
		                </a>
		              <?php }else{ ?>
		                
		              <?php } ?>
		            </td>
		          </tr>
		        <?php } ?>
		        </tbody>
		        </table>
		    </div>
	    <?php  }else{
	    	echo "Nenhum usuário encontrado.";
	    }
	}
    
?>