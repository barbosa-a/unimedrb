<?php
    //inicializar sessão
    session_start();
    //Biblioteca auxiliares
    include_once("config/config.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo nomeSistema; ?> | Login</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo pg; ?>/dist/plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo pg; ?>/dist/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo pg; ?>/dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <!-- /.login-logo -->
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <div class="row logos">
        <div class="col">
          
        </div>  
      </div>
      <a href="#" class="h1">
        <b><?php echo nomeSistema; ?></b><br>        
      </a>
    </div>
    <div class="card-body">
      <p class="login-box-msg">
        Faça login para iniciar sua sessão
        <?php
          if (isset($_SESSION['msg'])) {
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
          }
        ?>
      </p>

      <form action="<?php echo pg; ?>/valida_login.php" method="POST">
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="usuario" placeholder="Login de acesso" autofocus autocomplete="off">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" name="senha" placeholder="Senha de acesso" autocomplete="off">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Lembrar senha
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <input type="submit" class="btn btn-primary btn-block" name="btnLogin" value="Acessar" />
          </div>
          <!-- /.col -->
        </div>
      </form>

      <div class="row text-center mt-2 mb-3">
        <div class="col">
          <a href="<?php echo pg; ?>/pages/modulo/update-password/update.php" class="btn btn-block btn-primary">
            <i class="fa fa-key mr-2"></i> Trocar senha
          </a>
        </div>
        <!--<div class="col">
          <a href="<?php echo pg; ?>/pages/modulo/register-recover-password/forgot-password.php" class="btn btn-block btn-danger">
            <i class="fa fa-lock mr-2"></i> Solicitar senha
          </a>
        </div> -->
      </div>
      <!-- /.social-auth-links -->
      
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo pg; ?>/dist/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo pg; ?>/dist/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo pg; ?>/dist/js/adminlte.min.js"></script>
</body>
</html>
