<?php
if(!isset($seguranca)){
    exit;
}
function seguranca(){
    if((isset($_SESSION['usuarioEMAIL'])) AND (isset($_SESSION['usuarioNIVEL']))){
        
    }else{
        include_once("config/config.php");
        $_SESSION['msg'] = '<div class="alert alert-info alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                              <small><i class="icon fas fa-info"></i> Para acessar a página é necessario realizar login.</small>
                            </div>';
        $url_destino = pg."/login.php";
        header("Location: $url_destino");
    }
}
