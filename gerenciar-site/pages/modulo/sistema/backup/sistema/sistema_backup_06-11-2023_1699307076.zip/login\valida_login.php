<?php
    //inicializar sessão
    session_start();
    $btnLogin = filter_input(INPUT_POST, 'btnLogin', FILTER_DEFAULT);
    //Verificar se o usuário clicou no botão
    if ($btnLogin) {
        $seguranca = true;
        include_once("config/config.php");
        include_once("config/conexao.php");
        include_once("lib/lib_valida.php");
        $usuario_login = filter_input(INPUT_POST, 'usuario', FILTER_DEFAULT);
        $senha_login   = filter_input(INPUT_POST, 'senha', FILTER_DEFAULT);
        $usuario = limparSenha($usuario_login);
        $senha   = limparSenha($senha_login);
        //verificar se os campos estão vindo vazio ou não
        if((!empty($usuario)) AND (!empty($senha))){
            //echo password_hash($senha, PASSWORD_DEFAULT);
            $pesq_usuario = "SELECT * FROM usuarios us
                INNER JOIN unidade un ON un.id_uni = us.unidade_id 
                INNER JOIN cargo ca ON ca.id_cargo = us.cargo_id
                INNER JOIN niveis_acessos nv ON nv.id_nvl = us.niveis_acesso_id 
                LEFT JOIN contrato_sistema c ON c.idcontratosistema = us.contrato_sistema_id
                WHERE us.login_user = '$usuario' LIMIT 1 ";
            
            $query_pesq_usuario = mysqli_query($conn, $pesq_usuario);
            if(($query_pesq_usuario) AND ($query_pesq_usuario->num_rows > 0)){
                $row_usuario = mysqli_fetch_array($query_pesq_usuario);
                //verificar a situação do contrato
                if($row_usuario['situacao_contrato_id'] == 1 OR $row_usuario['id_user'] == 1 AND $row_usuario['contrato_sistema_id'] == null){
                    //verificar a situação da conta do usuário
                    if($row_usuario['situacoes_usuario_id'] == 1){
                        //usuário ativo e senha precisa ser alterada
                        $url_destino = pg."/pages/modulo/update-password/update-password.php?token={$row_usuario['token']}";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                    }elseif($row_usuario['situacoes_usuario_id'] == 2){
                        //usuario INATIVO no sistema
                        $_SESSION['msg'] = '<div class="alert alert-danger alert-dismissible">
                                              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                              <small><i class="icon fas fa-ban"></i> Usuário inativo!</small>
                                            </div>';
                        $url_destino = pg."/login.php";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                        
                    }elseif($row_usuario['situacoes_usuario_id'] == 3){
                        //usuario com senha RESETADA
                        $url_destino = pg."/pages/modulo/update-password/update-password.php?token={$row_usuario['token']}";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                    
                    }elseif($row_usuario['situacoes_usuario_id'] == 4) {
                        //usuario com senha EXPIRADA
                        $_SESSION['msg'] = '<div class="alert alert-danger alert-dismissible">
                                              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                              <small><i class="icon fas fa-ban"></i> Sua senha expirou e precisa ser alterada.</small>
                                            </div>';
                        $url_destino = pg."/login.php";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                        
                    }elseif($row_usuario['situacoes_usuario_id'] == 5) {
                        //consultar validade da senha atual
                        $senha_atual_user = "SELECT 
                                30 - TIMESTAMPDIFF(DAY, created_hist_senha, NOW()) AS dias
                            FROM 
                                hist_senha 
                            WHERE 
                                usuario_id = '{$row_usuario['id_user']}' 
                            AND
                                evento_senha_id = 1 
                            ORDER BY created_hist_senha DESC LIMIT 1 
                        ";
                        $query_senha_atual_user = mysqli_query($conn, $senha_atual_user);
                        $userSenha = mysqli_fetch_assoc($query_senha_atual_user);
                        if ($userSenha['dias'] < 1) {
                            //Redirecionar usuario para alterar senha
                            $url_destino = pg."/pages/modulo/update-password/update-password.php?token={$row_usuario['token']}";
                            echo '<script> location.replace("'.$url_destino.'"); </script>';    
                        }else{
                            //usuario ATIVO e senha foi alterada no primeiro login do sistema
                            if(password_verify($senha, $row_usuario['senha_user'])){
                                $ordem = "SELECT ordem_nvl FROM niveis_acessos WHERE id_nvl = '{$row_usuario['niveis_acesso_id']}' ";
                                $query_ordem = mysqli_query($conn, $ordem);
                                $ro_ordem = mysqli_fetch_assoc($query_ordem);

                                $_SESSION['usuarioID']    = $row_usuario['id_user'];
                                $_SESSION['usuarioFOTO']  = $row_usuario['foto'];
                                $_SESSION['usuarioNOME']  = $row_usuario['nome_user'];
                                $_SESSION['usuarioEMAIL'] = $row_usuario['email_user'];
                                $_SESSION['usuarioLOGIN'] = $row_usuario['login_user'];
                                $_SESSION['usuarioNIVEL'] = $row_usuario['niveis_acesso_id'];
                                $_SESSION['usuarioORDEM'] = $ro_ordem['ordem_nvl'];
                                $_SESSION['usuarioUNIDADEID']       = $row_usuario['unidade_id'];
                                $_SESSION['usuarioUNIDADE']         = $row_usuario['nome_uni'];
                                $_SESSION['usuarioUNIDADESIGLA']    = $row_usuario['sigla_uni'];
                                $_SESSION['usuarioCARGO']           = $row_usuario['nome_cargo'];
                                $_SESSION['usuarioPERFIL']          = $row_usuario['nome_nvl'];
                                $_SESSION['contratoID']             = $row_usuario['idcontratosistema'];
                                $_SESSION['contratoUSER']           = $row_usuario['contrato_sistema_id'];
                                $_SESSION['empresaNOME']           = $row_usuario['nome_fantasia'];
                                
                                $url_destino = pg."/";
                                echo '<script> location.replace("'.$url_destino.'"); </script>';
                            }else{
                                $_SESSION['msg'] = '<div class="alert alert-danger alert-dismissible">
                                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                                    <small><i class="icon fas fa-ban"></i> Senha incorreta!</small>
                                                    </div>';
                                $url_destino = pg."/login.php";
                                echo '<script> location.replace("'.$url_destino.'"); </script>';
                            }
                        }
                    }else {
                        $_SESSION['msg'] = '<div class="alert alert-danger alert-dismissible">
                                              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                              <small><i class="icon fas fa-ban"></i> Usuário não encontrado!</small>
                                            </div>';
                                            $url_destino = pg."/login.php";
                                            echo '<script> location.replace("'.$url_destino.'"); </script>';
                    } //verificar a situação da conta do usuário
                }elseif ($row_usuario['situacao_contrato_id'] == 2) {
                    $_SESSION['msg'] = '
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <small><i class="icon fas fa-ban"></i> Contrato inativo</small>
                        </div>';
                        $url_destino = pg."/login.php";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                }elseif ($row_usuario['situacao_contrato_id'] == 3) {
                    $_SESSION['msg'] = '
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <small><i class="icon fas fa-ban"></i> Contrato cancelado</small>
                        </div>';
                        $url_destino = pg."/login.php";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                }elseif (empty($row_usuario['anexo_contrato'])) {
                    $_SESSION['msg'] = '
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <small><i class="icon fas fa-ban"></i> Contrato inválido</small>
                        </div>';
                        $url_destino = pg."/login.php";
                        echo '<script> location.replace("'.$url_destino.'"); </script>';
                }else{
                    $_SESSION['msg'] = '
                        <div class="alert alert-warning alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <small><i class="icon fas fa-exclamation-triangle"></i> Usuário sem contrato</small>
                        </div>';
                        $url_destino = pg."/login.php";
                        echo '<script> location.replace("'.$url_destino.'"); </script>'; 
                }//verificar a situação do contrato           
            }
        }else{
            $_SESSION['msg'] = '<div class="alert alert-info alert-dismissible">
                                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                  <small><i class="icon fas fa-info"></i> Preencha o campo usuário e senha.</small>
                                </div>';
                                $url_destino = pg."/login.php";
                                echo '<script> location.replace("'.$url_destino.'"); </script>';
        }
    }else{
        $_SESSION['msg'] = '<div class="alert alert-warning alert-dismissible">
                              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                              <small><i class="icon fas fa-exclamation-triangle"></i> Página não encontrada</small>
                            </div>';
                            $url_destino = pg."/login.php";
                            echo '<script> location.replace("'.$url_destino.'"); </script>';
    }
?>