<?php
    if(!isset($seguranca)){
        exit;
    }
echo 'proc edita user';
