window.print();
window.onafterprint = back;
function back() {
    window.close();
}