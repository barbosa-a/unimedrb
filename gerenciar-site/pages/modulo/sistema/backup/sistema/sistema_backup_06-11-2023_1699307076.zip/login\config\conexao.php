<?php
if(!isset($seguranca)){
    exit;
}

$servidor = "localhost";
$usuario  = "root";
$senha    = "";
$banco    = "chamados";

//criar conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $banco);
if(!$conn){
    die("Falha ao conectar servidor: ". mysqli_connect_error());
}else{
    //echo "Conexão realizada com sucesso.";
}


?>
