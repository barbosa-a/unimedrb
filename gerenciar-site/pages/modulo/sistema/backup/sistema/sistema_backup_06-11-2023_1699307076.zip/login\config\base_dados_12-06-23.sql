-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12/06/2023 às 18:39
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `template_login`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_token`
--

CREATE TABLE `auth_token` (
  `idToken` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token` mediumtext NOT NULL,
  `criado_token` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `auth_token`
--

INSERT INTO `auth_token` (`idToken`, `usuario_id`, `token`, `criado_token`) VALUES
(1, 1, 'D2195E56EE2C0921029FA71A9340D78751F00CE0B5AE0ED8F4B6D05F818AFF56', '2023-04-26 18:09:09'),
(2, 1, 'CC808C0F36BFBF1540925CFD9D95FAACF76476624CCD6961CF544FF309FECD37', '2023-04-26 19:09:14'),
(3, 1, 'D846F61095826181008E3335A18EFEE058C9AD8431D9F5EFC5118C5E6E02E832', '2023-04-26 20:11:14'),
(4, 1, 'C6A25E7AEA6086DA9E546EB1BD6AABE67C369AC6306C172BBCAC19895553E4F7', '2023-04-26 22:20:54'),
(5, 1, 'BB4071349917A670CF1DA251156977EC750742168A09F1BE72FDC4C3321BB906', '2023-04-27 13:49:08'),
(6, 1, 'FB2765924842A2839AB70113BE1140205A684023DEDF7F1746195C6C2FBC97F0', '2023-04-29 11:20:51'),
(7, 1, '82AE78ECAFECABCCD6420C62DCEB6C27D2270B8AB0F2CE214B54E1587210ADA2', '2023-04-29 15:15:26'),
(8, 1, '936C32ADE544DDE8FCA5E2AA85480C740CE98434F74E490DC4A790685DA54451', '2023-04-30 17:25:24'),
(9, 1, 'B8398C752773208AB99FD1DA78D9590AD5BC2EABF3443785884C9F4BB49914E4', '2023-04-30 21:53:24'),
(10, 1, '12D1D1E830BDB304D92C18E13717D3A3746CE184FD0B099DA7B8F26F09E4A130', '2023-04-30 23:02:27'),
(11, 1, 'E5FFC1DD1EDCA4C950D72DEC363797767A5A70DE3BBE4CC04040320F73BF1275', '2023-05-01 00:09:04'),
(12, 1, '87B6D36946E8CA1F440334F17D5B8E655F8FBAB397CC77A97DBAEB3B3187FEB0', '2023-05-02 09:52:49'),
(13, 1, '5181AA0FC73E6B5D4CAB9B329C967F87E4B271A0E1830D18D58406DA32A54A52', '2023-05-02 14:12:19'),
(14, 1, 'CCD41A468A1E4DEC8FB9D883B69B0AFACD743FD0DD99E7A5A561176C9C4757AF', '2023-05-02 15:21:01'),
(15, 1, 'FE17575137A450AE09AA809E805306CCCF04BEF58B8EDC742971EEFCD41F2A56', '2023-05-03 17:51:31'),
(16, 1, 'EC06D7792DD2C99DBED1573A6A22F87A328A0FAF02E524F2295DC158F3693B2A', '2023-05-03 18:58:38'),
(17, 1, 'B6AB7B86BCE00B05AE790365CB449FDB3B1C913FD823BB4FE7C32C2552237158', '2023-05-03 20:01:38'),
(18, 1, '63621778563AFE1671F25EF7A88ABF417A9BB73250C02E69A7114CD65FB96FE8', '2023-05-03 21:13:15'),
(19, 1, 'A98F1104B8501A41B909F4F4C0D60AD09E6C7BE230F75D853D811F40E49DA87C', '2023-05-03 22:13:18'),
(20, 1, 'EC23B98C78682D8447D4C23DF64ACC344BC29A51414941CDF2041D8A8B177FF6', '2023-05-05 17:48:47'),
(21, 1, 'F2A644421734CCC54624F9C61482B764045F7F4F15D76366E8A6EB27851BDD18', '2023-05-05 19:01:45'),
(22, 1, 'C3518B19868945945D5A5A6AE06C5374B27C81CED46A37AF0A2374141B41DA5E', '2023-05-05 20:01:58'),
(23, 1, 'F8B923402A299A1CF1C6F4AB6581579D1C66A4498C442C0472576A09C118D73C', '2023-05-05 21:02:09'),
(24, 1, '5228DF91C7917A0318E498B000EF9B0660B644253737CE40709EB892043C6BF4', '2023-05-05 22:02:55'),
(25, 1, '9261B931588E80B72C55421C254A0A9F36F794C749565D12A8C0E80B073AD956', '2023-05-06 15:11:46'),
(26, 1, 'A56333E27FFE9F9A26C8A916607A807E77638C456161030332EC466C2E72B6EF', '2023-05-06 16:17:14'),
(27, 1, '4206171457CD2A85C0C9D458EC94DF62B6845B1649464F6B8F39BE122955D8D2', '2023-05-06 17:23:04'),
(28, 1, '7108D67B4A6A8CA1A9DA01CA991AFF7823BBCE0CFEA8F591F4591ED027B52172', '2023-05-06 19:40:56'),
(29, 1, 'D6278F219DA9CCCA714623DB5F26DBB6F9B1806A61CDC4D320D8413C83C11194', '2023-05-06 20:41:11'),
(30, 1, '71A2A660B4FB905732CFB9C46790A184EF54FA1A7ECEE1AA5DD16A8094C2570C', '2023-05-06 21:45:13'),
(31, 1, '1704CFAB5AA6964E688AAE9FAEF192E51743F34A1435550446C394FB65D70F7D', '2023-05-07 11:18:43'),
(32, 1, '4F5F3D8C56364738F5581888C63CF406267B23B0B3DC71F65994F553A0556C50', '2023-05-07 17:23:00'),
(33, 1, '49E1901F1AC3A50BDC8649C2AA37D233F047AD47CB6B0D522AB37876AF308926', '2023-05-07 18:48:16'),
(34, 1, '3E2285BA1240651E44454D6FAB3FF41A413336FAE5CE0281EDC9C9227BD6192B', '2023-05-07 19:50:29'),
(35, 1, '7293513F4C5C6D5707F2B834757A209D6836ACC838277C96B99E229290094D5C', '2023-05-07 20:50:57'),
(36, 1, '0E9AD6A0FB02FD84FECF5AEC60E342F8E42AAFA09AD0A238877745B4BF2BC4C6', '2023-05-07 21:51:27'),
(37, 1, '2B9207F2BAA9CE7352A187F43FF2DF307C92FC1B6ADBBCB493268E4EC86256CF', '2023-05-07 23:07:13'),
(38, 1, 'FB6BE3C049F60DAE8147B94415D55CDCDE73404C9F4CCE4203410C6862C6FFCD', '2023-05-08 17:50:06'),
(39, 1, '24F5AFA209849AE09208A9C1C0C7D6E95F1910A4415637FCB0AD6C6CBDE33293', '2023-05-08 19:10:46'),
(40, 1, '73FE584F356AD4F74C96E21E0DEA2098F4EF5372C1DE03A7B04F4BDD86FD8915', '2023-05-08 21:23:33'),
(41, 1, 'FB2B5A1408DCD023B041E4CD16B50632073A68CC41E8D58FFFA62149997C47BF', '2023-05-10 18:51:53'),
(42, 1, 'FF51EC3628E875D65111484002522D41D2FD8CD510401B86CAB2A0771A131173', '2023-05-10 20:02:00'),
(43, 1, '16FF3913EC16AF44B4F5C6D00521CF9A4277E2291F9337FA5790EBFDE2605E1D', '2023-05-10 21:04:56'),
(44, 1, 'B445988F740D19F58560663DAAF4D4A52CC3202FAF06F53E9092A2D82D3638EC', '2023-05-10 22:28:51'),
(45, 1, 'AF402F99EC333F44B8204D996FA729906E12EC81F70F148896904383CD1B2B7E', '2023-05-11 20:21:55'),
(46, 1, '77DC223E81AACE9DCCFF7530830F0F1567817F04B9239E1F84627C49CB2E8C11', '2023-05-12 02:24:59'),
(47, 3, 'B7D635067398F969DCC5D3492883E03A9266CBB2A4A221DE037D8C5686D87941', '2023-05-12 02:24:59'),
(48, 4, '10DE0F49E01FDF0070F71FF6B26575B698956CC003978C76DF211D0DF4CE4153', '2023-05-12 02:24:59'),
(49, 1, 'CB9CBE7D04F42B3D966942DF83968E4A12EFB2EDE72585CD368AD9EEAD11E9FE', '2023-05-12 12:56:39'),
(50, 3, '49A169B4FD4ECD270112EF336EDC849271A95126E7B7138D10B60B97895849BC', '2023-05-12 12:56:39'),
(51, 4, 'E097C53985D39D04C9686E8D8674B73C049FDCA19B3BB5CFE8BAEA49F86DCC5E', '2023-05-12 12:56:39'),
(52, 1, '44DC2B99C66E5B8224EBE4E402AEC37DDB37951F24C5EC2863BC1B1F054D4715', '2023-05-16 07:43:46'),
(53, 3, 'BE429F806C654CDC5056AC11F0431CF81B534F457A67EC016EBE713695345804', '2023-05-16 07:43:46'),
(54, 4, '011683B98E009F397DEBD3FB6C6383688E140A953DB2064D46E7D2904286BC2C', '2023-05-16 07:43:46'),
(55, 1, 'FE3B6336AF1BBBA44271F7C410F650E0A9B71A0E5C0D5C59EC6F72BDC755E347', '2023-05-16 08:43:56'),
(56, 3, '29BD34F5524EF53FCE9539891656FB89D1829D83AF292DE29C0B77C83894B4D0', '2023-05-16 08:43:56'),
(57, 4, 'A3E33B73AC9ADEDD9345EF81504336B6C5632B6333AF7DFCA8090BA147E774D6', '2023-05-16 08:43:56'),
(58, 1, '97A893FF54952362A207D820C84960C430B709EC5E691B5E2AAC089729A0FCC9', '2023-05-16 10:59:26'),
(59, 3, '753FEFF11CF029112AF9429023F1006972328A89350508A054E54FAE3F93559F', '2023-05-16 10:59:26'),
(60, 4, '3BAB7C0A1F39072C9394686A367B9A683DF4CFD7009D527AC51FA75275AEC466', '2023-05-16 10:59:26'),
(61, 1, '838013BB3DE21B058E0518E81198D37C9AE4E79F86CF081C5104C1E25AB4414B', '2023-05-17 09:01:48'),
(62, 3, '0D30BA9885C15BEF3046A8C9ED600C2A2E01CEF39E635ED4A1BAD49F745CFE90', '2023-05-17 09:01:48'),
(63, 4, '993B1287E01518A523D59E66F5C72E852C57ACEFBA78EED2F664045B06831989', '2023-05-17 09:01:48'),
(64, 1, 'FEC4703C60500308D7C888B7827954FE843CC156BCDCD16BBB954442B848D9C2', '2023-05-17 10:04:14'),
(65, 3, 'B44BAAA726D77E29D03421ECE2860EBC3DB5D586EE956700B7EA2862D2366E80', '2023-05-17 10:04:14'),
(66, 4, '35838F6C1EC4353ECFFD0538B526B1A251D9BBA460B74A4E3118B85154FBF525', '2023-05-17 10:04:14'),
(67, 1, 'E491C2EA72880D457E5C4854EAE300617EB0389977E2EE74D28DAEBB8DFF86C5', '2023-05-17 11:11:07'),
(68, 3, 'E6957C52E3107738FD7E3255DAA2DF31E5B26355D6EB8FDF877950F32C8F36D5', '2023-05-17 11:11:07'),
(69, 4, '39958E953F097081E538CC6B3DB332DE8BE9F94012270A50B5AD408696DB84A0', '2023-05-17 11:11:07'),
(70, 1, 'B178E63335CE37D9B2DBCC9DB47889E54741DA4DD67A39CF55CD5B67846C24E6', '2023-05-17 12:32:45'),
(71, 3, '8993D282290193FCA2D2EABCD7E195F5E1247A894A93DCEA9B90008240599EAC', '2023-05-17 12:32:45'),
(72, 4, 'AEFDB26353D0F90B97373F917618B2C685EDB6AF2CD1D6A75FE0AF8C64019AF3', '2023-05-17 12:32:45'),
(73, 1, '4C613EA21D7614A6C71C9C399DFD3E71775D5534294F55346DE150C66AE1F1BE', '2023-05-22 09:32:04'),
(74, 3, '49256FC0A6E9FC05A78F610DE16AC13BB98A6F8F72EE4702622D1DC0DE21C4C8', '2023-05-22 09:32:04'),
(75, 4, '066060CD9FDF1DF429375BCB76CE1E9D754B55469BE9057515C54621900F380A', '2023-05-22 09:32:04'),
(76, 1, '64DF50B543264B83DF4A6548A1CE8B0189C0F0FEE4DAB7BBEE040A9DC6071BE6', '2023-05-23 07:32:58'),
(77, 3, '91894C8EBC079257C48625C96E47F7E7F3F6180F9E7A53E9713EC81DC20F23E8', '2023-05-23 07:32:58'),
(78, 4, '3BB00E23AF004C449EE0F9B2C12E81B5F94313EEDCC783C335BD256AFB10C49E', '2023-05-23 07:32:58'),
(79, 1, 'E0C5FB0D29128DB606C6899D35018E7742BFCDDC41805B9F9CF220FB2267E4D4', '2023-05-25 08:52:26'),
(80, 3, '2F98A2A908FF157734B543EF2404FF52A237F3EBDF72AD8BD5F813A9AE57DECC', '2023-05-25 08:52:26'),
(81, 4, '8219815FBD7C10EA24D8D04F9993FED6EF998B3B8D9B6A069053F764E4C0134E', '2023-05-25 08:52:26'),
(82, 1, '9ED96D321D782D21793657C6D2C143A3CFAA5F2A11BC10872AD015A6CDEC1239', '2023-05-25 10:33:30'),
(83, 3, 'B18294D0804F1A602259A5AAD9F23FFFF086A1B6F26EC373C0F8C629AC186AAA', '2023-05-25 10:33:30'),
(84, 4, 'DFF89218FB4C6FC7FB364D23515E810BF6B62BCD10159922640076CE986CBE92', '2023-05-25 10:33:30'),
(85, 1, '1E0C362C9218E31B0D45F605B061412107651854F4A282B93FA19F1579351214', '2023-05-25 11:46:50'),
(86, 3, 'B635F25F50875BCDDB263C78B8382E46E9DD25025211A39D5EB515F87DE60FF9', '2023-05-25 11:46:50'),
(87, 4, '3CA94D2939CC31EF5837AC314DC2A547CEA35F0E711003B57A6203A91FF5EEB2', '2023-05-25 11:46:50'),
(88, 1, '38DBEDB6F4A9C51316CFA7C6F0C1948A759C29B59B88636208FF503D2368F2E1', '2023-05-26 08:54:30'),
(89, 3, 'A416D324DE5940CF8358B32BB08561D76B824A2094889D204503C3B0184FB720', '2023-05-26 08:54:30'),
(90, 4, 'FB744438971C4CAC3410FE4971AFC3ECD25AF2B656F5A39D5E4F7D0FDD9A1033', '2023-05-26 08:54:30'),
(91, 1, 'EE23A9F47604B1CFE5EAEAE94FAC3CDDBE427D9984E1117B8A75F8DDEC23E0B1', '2023-05-26 09:55:08'),
(92, 3, '6D80B299BBBA05053B719E50E0DFEC11ED7C7243D7DF0221D3172AD2C49CE921', '2023-05-26 09:55:08'),
(93, 4, '27EF0C4FAB84499B4979D599C9DD17F5AC6E8D419EA8B5CCD87D2619C6376806', '2023-05-26 09:55:08'),
(94, 1, '07BAFD532A7ABD1A186D671D0F9C30945F5F21C1E7EC3C04036C841C58F798C8', '2023-05-27 14:06:41'),
(95, 3, 'ED0462D8C996D5C28D203CC02F8B044D75DDC28A687BD4ED3F01C5104D70559C', '2023-05-27 14:06:41'),
(96, 4, 'F4AC0A041785BEBD10EA70D72BFEA149A34D80974A9A76A1D4D5AFED3B618680', '2023-05-27 14:06:41'),
(97, 1, 'B77372A62F98F36AB50D38A37C26DCBAABCF6906D882DB755EA2ACCD61DF53E0', '2023-05-27 15:10:00'),
(98, 3, '1F265B3450C716E3111823122230C036BEC98BB6E070D02BBAE6386D4CF5DD77', '2023-05-27 15:10:00'),
(99, 4, 'A497B271EB3F29B54C93E5233A7BCA3F25B2B6A3FEB14CBEE68C958332307865', '2023-05-27 15:10:00'),
(100, 1, 'D502148B06B24591EA68EB7931CA2545601220D31765579B7A387444E1D751F9', '2023-05-27 16:35:41'),
(101, 3, 'E4AED7119221E58003AD52E0D3BD8E2920F4569F800B6523806578B08258D5A1', '2023-05-27 16:35:41'),
(102, 4, 'F9D1C03224E1DCCD4DD4BC0A8AB1A40274B379A2BC711852A8CFB484E64A30E4', '2023-05-27 16:35:41'),
(103, 1, 'DEE4A8F51F75A6575C09EF0B208CB1C9B6041990D27EB82A98BC0A26683E27FC', '2023-05-27 17:37:03'),
(104, 3, '5662DF844886F9B3573F0315241F785BEAA59CBA030208C1F61BA16281DC7016', '2023-05-27 17:37:03'),
(105, 4, '05D21853CF4B1929262C6500BB1C8EF85944496D41CB983EBD616F2A28E1D525', '2023-05-27 17:37:03'),
(106, 1, '48D6902E8DEF067B6530DBF62E97C982EA89F9EED452C16B57DF0891D72B7A45', '2023-05-27 18:41:03'),
(107, 3, 'CFA19E5ED07C75B66E07A7505BC3E34B529B5A1DAAD2D5C22FE47FD786861440', '2023-05-27 18:41:03'),
(108, 4, '8C9AF27C88DB44CE978EE42840C185E7EC497876509197C83BBFE2931BFF3AB2', '2023-05-27 18:41:03'),
(109, 1, '8D4DF44D5FEF121E4FC9834EF43AE3566C06109E53ACA3C6034CCABB65C892B9', '2023-05-28 09:30:06'),
(110, 3, '9DE1AA4312B70DCE8E0420FBE9608D6127EE1F11CD3B01F2F2B239CEE330AF3B', '2023-05-28 09:30:06'),
(111, 4, '36FFAC15D31A53EC341915C8040356F994AA8B028D75737150A7C39FB4FECC1B', '2023-05-28 09:30:06'),
(112, 1, '4978B749B27F9E35D501B8A9F5093C015CAA9B5FBA9D9755C4452489DD818587', '2023-05-28 10:49:12'),
(113, 3, '0FD00348AD10E8BBC30E9F225B3FBE8D278FC0E6AB2B3F9A2B18E62700359925', '2023-05-28 10:49:12'),
(114, 4, '66D3B56C3B657AEE6A6EB9732B966C0604899A8898DE94B597EB1DAE65BBF7F2', '2023-05-28 10:49:12'),
(115, 1, 'FAF9F8E0811195FB3A3ED0BF73F7A08F1B3F32894A1886ECA18AC34A5883F800', '2023-05-28 11:51:57'),
(116, 3, '4365E0884105D15259D759F249B691930547E8C280F61DA85ADE9B629E59C7FD', '2023-05-28 11:51:57'),
(117, 4, 'C786A159FDAE88E3F044666C7969159E0F18B9B56523DBD9FB8AFDBC6DDBA69F', '2023-05-28 11:51:57'),
(118, 1, '2BA90C4FB1460F585F91676E7FD98528A764D823F87EFE443DC0F713AC09C6ED', '2023-05-28 19:24:53'),
(119, 3, '7FDB39593D5CF8A1705CF666F651AC8E7233319B3633EB03AC5242BECC30FC14', '2023-05-28 19:24:53'),
(120, 4, 'F16B4D0E9141420C8E48C8EC629B37458080535283A50914AE25D025E046C73E', '2023-05-28 19:24:53'),
(121, 1, '1678E2695491ED760DF097EC41EADC5D764B2FB5ECF5BC434ACC4FBB26087FA4', '2023-05-28 20:28:00'),
(122, 3, 'A02003B3FF435436A9659F0579DF26E5E91A2837AD094DF455E302393174C381', '2023-05-28 20:28:00'),
(123, 4, 'EB41329B2CFCF12D5458A45F34389C7A32598427CEF380F65215BD81CCC9CE0F', '2023-05-28 20:28:00'),
(124, 1, '241A4852FAAD2D147ECD86A206F4D2603EAD5AC67905CD53747AB745458E3734', '2023-05-28 21:28:25'),
(125, 3, '0804C48CC7B5C01AEAFD7420CC8D04A0442770FC32F284F018977D20FA750153', '2023-05-28 21:28:25'),
(126, 4, '98A3B96A2F982F9F5AE869F350433FD85C37795C02ADB4CC93EB27040D7040C0', '2023-05-28 21:28:25'),
(127, 1, '62461F2D4C4D3B83AD2A4A54C1464D0B48FF9FB548BE230CBA3C358AD0CA0BA7', '2023-06-09 16:28:56'),
(128, 3, 'F2C898C98FEE82035629CF7917A7640A5B2B5AA04DFE9186FECF8054EB4B068D', '2023-06-09 16:28:56'),
(129, 4, '6691F7A27971043AA0ABBF94F1E057EA25D607B7AB39AE1256ED4BF79C27F85C', '2023-06-09 16:28:56'),
(130, 1, 'BA40BB4B926C3F21698FF91E9293D658DE89D9683628C59BEFE093E720A8B181', '2023-06-12 10:25:06'),
(131, 3, '75B17A56B9D96BF772E5D3447F4E3D4591ADF2CB3A9CBC3E4639793B249DD535', '2023-06-12 10:25:06'),
(132, 4, '2FE81D9302F1D6105CCD1C8602E49FC08062CDAA5AE6BA67D0EB8B87264F83D3', '2023-06-12 10:25:06'),
(133, 3, '75D3BABAA34EB94D524AFBF1E92CD3E86456B6FAF7413A00B90BC4B86809C883', '2023-06-12 11:25:47'),
(134, 4, '771BF4291504F5F2BA8D1A8AE4FF539A800C3833357185B6DE77A0239190DFCA', '2023-06-12 11:25:47');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cargo`
--

CREATE TABLE `cargo` (
  `id_cargo` int(11) NOT NULL,
  `nome_cargo` varchar(255) NOT NULL,
  `departamento` int(11) NOT NULL,
  `descricao_cargo` mediumtext DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_cargo` datetime NOT NULL,
  `modificado_cargo` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `cargo`
--

INSERT INTO `cargo` (`id_cargo`, `nome_cargo`, `departamento`, `descricao_cargo`, `usuario_id`, `criado_cargo`, `modificado_cargo`) VALUES
(1, 'Front-end Developer', 8, 'Front-end Developer', 1, '2020-09-21 00:00:00', '2021-12-17 18:56:48'),
(12, 'Gerente financeiro', 5, '', 1, '2021-07-13 23:11:44', '2021-12-17 18:52:27'),
(14, 'Administrador de sistemas', 8, '', 1, '2021-12-17 18:54:26', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria_versao`
--

CREATE TABLE `categoria_versao` (
  `idcatversao` int(11) NOT NULL,
  `icone` varchar(100) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `mudanca` varchar(200) NOT NULL,
  `desc_mudanca` text NOT NULL,
  `created_mudanca` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `categoria_versao`
--

INSERT INTO `categoria_versao` (`idcatversao`, `icone`, `titulo`, `mudanca`, `desc_mudanca`, `created_mudanca`) VALUES
(1, 'fa fa-check bg-primary', 'Adicionado', 'Novas funcionalidades', 'Added/Adicionado para novas funcionalidades.', '2021-12-20 01:42:07'),
(2, 'fa fa-code bg-info', 'Modificado', 'Mudanças em funcionalidades existentes', 'Changed/Modificado para mudanças em funcionalidades existentes.', '2021-12-20 01:42:07'),
(3, 'fa fa-exclamation-triangle bg-warning', 'Obsoleto', 'Removidas das próximas versões', 'Deprecated/Obsoleto para funcionalidades estáveis que foram removidas das próximas versões.', '2021-12-20 01:42:07'),
(4, 'fa fa-times bg-danger', 'Removido', 'Funcionalidades removidas desta versão', 'Removed/Removido para funcionalidades removidas desta versão.', '2021-12-20 01:42:07'),
(5, 'fa fa-bug bg-success', 'Corrigido', 'Correção de bug', 'Fixed/Consertado para qualquer correção de bug.', '2021-12-20 01:42:07'),
(6, 'fa fa-key bg-gray', 'Segurança', 'Atualização de segurança', 'Security/Segurança para incentivar usuários a atualizarem em caso de vulnerabilidades.', '2021-12-20 01:42:07');

-- --------------------------------------------------------

--
-- Estrutura para tabela `changelog`
--

CREATE TABLE `changelog` (
  `idchangelog` int(11) NOT NULL,
  `versoes_id` int(11) NOT NULL,
  `categoria_versao_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `descricao` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modifield` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `changelog`
--

INSERT INTO `changelog` (`idchangelog`, `versoes_id`, `categoria_versao_id`, `usuario_id`, `descricao`, `created`, `modifield`) VALUES
(1, 1, 1, 1, 'Adicionado submenu contrato do modulo sistema', '2021-12-19 23:47:19', NULL),
(2, 1, 1, 1, 'Adicionado botão editar do submenu contrato do modulo sistema.', '2021-12-19 23:56:32', NULL),
(3, 1, 1, 1, 'Adicionado o botão para atualizar o anexo do contrato no card de anexos do contrato.', '2021-12-19 23:58:32', NULL),
(4, 1, 2, 1, 'Realizada a integração do contrato do cliente na validação do login. Permitindo somente o acesso ao sistema usuários vinculados a um contrato previamente cadastrado.', '2021-12-20 00:02:16', NULL),
(5, 1, 2, 1, 'Criada as seguintes validações de login no arquivo valida_login.php: <br>\r\n1. Validação da situação (Ativo, Inativo ou Cancelado) do contrato. <br>\r\n2. Validação de senhas expiradas no período de 30 dias. <br>\r\n3. Verificar se o usuário ao realizar login está vinculado em algum contrato. <br>\r\n4. Validar se o contrato foi cadastrado corretamente para o usuário. Caso contrário impedir o acesso ao sistema retornado a mensagem: contrato inválido. <br>\r\n5. Caso não passe por nenhuma das validações retorna que o usuário não possui contrato (Usuário sem contrato).', '2021-12-20 00:09:06', NULL),
(7, 1, 1, 1, '<ol><li>Inserido o botão/ícone no card changelog para cadastrar os registros de alteração do sistema.</li><li>Adicionada query para ordenar a exibição dos registros do changelog por ordem decrescente.<br><br></li></ol>', '2021-12-20 20:03:09', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `chat_message`
--

CREATE TABLE `chat_message` (
  `idchat` int(11) NOT NULL,
  `from_user` int(11) NOT NULL,
  `to_user` int(11) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `contrato_sistema`
--

CREATE TABLE `contrato_sistema` (
  `idcontratosistema` int(11) NOT NULL,
  `razao_social` varchar(255) NOT NULL,
  `nome_fantasia` varchar(220) DEFAULT NULL,
  `cnpj` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `resp_financeiro` varchar(100) NOT NULL,
  `telefone` varchar(50) NOT NULL,
  `cep` varchar(9) NOT NULL,
  `rua` varchar(255) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `plano` varchar(50) NOT NULL,
  `modelo_plano` varchar(50) NOT NULL,
  `vencimento` date DEFAULT NULL,
  `valor_contrato` double NOT NULL,
  `inicio_contrato` date NOT NULL,
  `fim_contrato` date NOT NULL,
  `anexo_contrato` varchar(255) NOT NULL,
  `qtd_usuarios_liberados` int(11) DEFAULT NULL,
  `situacao_contrato_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_contrato` datetime NOT NULL,
  `modifield_contrato` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `contrato_sistema`
--

INSERT INTO `contrato_sistema` (`idcontratosistema`, `razao_social`, `nome_fantasia`, `cnpj`, `email`, `resp_financeiro`, `telefone`, `cep`, `rua`, `numero`, `bairro`, `cidade`, `estado`, `plano`, `modelo_plano`, `vencimento`, `valor_contrato`, `inicio_contrato`, `fim_contrato`, `anexo_contrato`, `qtd_usuarios_liberados`, `situacao_contrato_id`, `usuario_id`, `created_contrato`, `modifield_contrato`) VALUES
(1, 'POLICLINICA', 'Poli', '00000000000000', 'policlinica@gmail.com', 'Nemersson', '6800000000', '69906-400', 'Travessa MarmorÃ©', '283', 'TaquarÃ­', 'Rio Branco', 'AC', 'Mensal', 'Premium', '2023-05-31', 250, '2023-05-11', '2040-12-31', '1683855217645d9771746cb.pdf', 999999, 1, 1, '2023-05-11 20:33:37', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `departamento`
--

CREATE TABLE `departamento` (
  `id_depar` int(11) NOT NULL,
  `nome_depar` varchar(255) NOT NULL,
  `descricao_depar` mediumtext NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_depar` datetime NOT NULL,
  `modificado_depar` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `departamento`
--

INSERT INTO `departamento` (`id_depar`, `nome_depar`, `descricao_depar`, `usuario_id`, `criado_depar`, `modificado_depar`) VALUES
(5, 'Departamento Financeiro', '', 1, '2021-07-13 23:08:19', NULL),
(8, 'Departamento de TI', '', 1, '2021-07-13 23:09:22', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `enquete`
--

CREATE TABLE `enquete` (
  `idenquete` int(11) NOT NULL,
  `contrato_sistema_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `resultado` int(11) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `enquete`
--

INSERT INTO `enquete` (`idenquete`, `contrato_sistema_id`, `usuario_id`, `resultado`, `obs`, `created`) VALUES
(1, 0, 1, 5, '', '2023-05-11 20:34:51'),
(2, 1, 3, 5, 'ok', '2023-05-11 20:42:51'),
(3, 1, 4, 5, 'ok2', '2023-05-11 20:44:10'),
(4, 0, 1, 4, '', '2023-06-12 11:37:19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `enquete_rating`
--

CREATE TABLE `enquete_rating` (
  `idrating` int(11) NOT NULL,
  `nome` varchar(10) NOT NULL,
  `pts` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `enquete_rating`
--

INSERT INTO `enquete_rating` (`idrating`, `nome`, `pts`) VALUES
(1, 'Ótimo', 5),
(2, 'Muito bom', 4),
(3, 'Bom', 3),
(4, 'Regular', 2),
(5, 'Ruim', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `evento_senha`
--

CREATE TABLE `evento_senha` (
  `id_eventoSenha` int(11) NOT NULL,
  `nome_evento` varchar(255) NOT NULL,
  `obs_evento` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `evento_senha`
--

INSERT INTO `evento_senha` (`id_eventoSenha`, `nome_evento`, `obs_evento`) VALUES
(1, 'Atribuição de senha', 'Quando o usuário altera sua senha.'),
(2, 'Troca de senha', 'Quando o operador de sistemas altera a senha do usuário'),
(3, 'Senha via sistema/cadastro', 'Quando a senha é cadastrada no ato do cadastro do usuário'),
(4, 'Senha expirada', 'Quando a vida útil da senha chega em 40 dias ');

-- --------------------------------------------------------

--
-- Estrutura para tabela `grupo`
--

CREATE TABLE `grupo` (
  `id_gru` int(11) NOT NULL,
  `nome_gru` varchar(220) NOT NULL,
  `descricao_gru` mediumtext DEFAULT NULL,
  `grupo_pai_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_gru` datetime NOT NULL,
  `modificado_gru` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `grupo`
--

INSERT INTO `grupo` (`id_gru`, `nome_gru`, `descricao_gru`, `grupo_pai_id`, `usuario_id`, `criado_gru`, `modificado_gru`) VALUES
(1, 'Raiz', 'Grupo padrão do sistema', 1, 1, '2020-09-23 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `hist_senha`
--

CREATE TABLE `hist_senha` (
  `id_histSenha` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `operador` int(11) NOT NULL,
  `evento_senha_id` int(11) NOT NULL,
  `created_hist_senha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `hist_senha`
--

INSERT INTO `hist_senha` (`id_histSenha`, `usuario_id`, `operador`, `evento_senha_id`, `created_hist_senha`) VALUES
(1, 3, 1, 3, '2023-05-11 20:33:37'),
(2, 3, 3, 1, '2023-05-11 20:38:30'),
(3, 4, 3, 3, '2023-05-11 20:42:34'),
(4, 4, 4, 1, '2023-05-11 20:43:19'),
(5, 1, 3, 2, '2023-05-12 02:27:45'),
(6, 1, 1, 1, '2023-05-12 02:28:27'),
(7, 1, 2, 4, '2023-06-12 10:25:06'),
(8, 1, 1, 1, '2023-06-12 10:38:06');

-- --------------------------------------------------------

--
-- Estrutura para tabela `modelos_plano`
--

CREATE TABLE `modelos_plano` (
  `idmodeloplano` int(11) NOT NULL,
  `nome_mod_plano` varchar(200) NOT NULL,
  `valor_plano` double NOT NULL,
  `plano_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_modelo_plano` datetime NOT NULL,
  `modifield_modelo_plano` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `modelos_plano`
--

INSERT INTO `modelos_plano` (`idmodeloplano`, `nome_mod_plano`, `valor_plano`, `plano_id`, `usuario_id`, `created_modelo_plano`, `modifield_modelo_plano`) VALUES
(1, 'Premium', 2750, 1, 1, '2021-12-15 00:01:09', NULL),
(2, 'Premium', 250, 2, 1, '2021-12-15 00:01:57', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `modulos`
--

CREATE TABLE `modulos` (
  `id_mod` int(11) NOT NULL,
  `nome_mod` varchar(200) NOT NULL,
  `chave_mod` varchar(200) NOT NULL,
  `descricao_mod` mediumtext NOT NULL,
  `permissao_mod` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `created_mod` datetime NOT NULL,
  `modifield_mod` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `modulos`
--

INSERT INTO `modulos` (`id_mod`, `nome_mod`, `chave_mod`, `descricao_mod`, `permissao_mod`, `usuario_id`, `created_mod`, `modifield_mod`) VALUES
(1, 'Controle de acesso', 'pages/modulo/controle_de_acesso', 'Configurações gerais do sistema', 1, 1, '2020-11-17 00:00:00', NULL),
(2, 'Página inicial', 'pages/modulo/home', 'Página inicial do sistema', 1, 1, '2020-11-17 00:00:00', '2023-06-12 11:36:39'),
(6, 'Meu perfil', 'pages/modulo/perfil', 'Perfil do usuário', 1, 1, '2021-03-25 00:00:00', '2021-12-08 16:47:13'),
(8, 'Importação', 'pages/modulo/importar', 'Importação e exportação de dados', 1, 1, '2021-05-03 00:00:00', '2023-06-12 11:36:19'),
(12, 'Sistema', 'pages/modulo/sistema', 'Modulo de administração do sistema', 1, 1, '2021-05-22 00:00:00', '2021-12-08 16:46:20'),
(13, 'Cadastro', 'pages/modulo/Cadastro', 'Cadastro', 1, 1, '2023-04-26 19:05:38', NULL),
(14, 'Painel de cadastro', 'pages/modulo/painel_cadastro', 'Painel de autorizaÃ§Ãµes cadastrais', 1, 1, '2023-05-07 19:55:19', '2023-05-07 19:55:43'),
(15, 'logout', 'pages/modulo/logout', 'Sair do sistema', 1, 1, '2023-06-12 11:34:24', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `niveis_acessos`
--

CREATE TABLE `niveis_acessos` (
  `id_nvl` int(11) NOT NULL,
  `nome_nvl` varchar(100) NOT NULL,
  `ordem_nvl` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_nvl` datetime NOT NULL,
  `modificado_nvl` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `niveis_acessos`
--

INSERT INTO `niveis_acessos` (`id_nvl`, `nome_nvl`, `ordem_nvl`, `usuario_id`, `criado_nvl`, `modificado_nvl`) VALUES
(1, 'Master', 1, 1, '2020-09-16 00:00:00', '2020-10-02 17:40:20');

-- --------------------------------------------------------

--
-- Estrutura para tabela `niveis_acessos_paginas`
--

CREATE TABLE `niveis_acessos_paginas` (
  `id_nvl_pg` int(11) NOT NULL,
  `niveis_acesso_id` int(11) NOT NULL,
  `pagina_id` int(11) NOT NULL,
  `permissao` int(11) NOT NULL,
  `menu` int(11) NOT NULL DEFAULT 2,
  `ordem` int(11) NOT NULL,
  `criado_nvl_pg` datetime NOT NULL,
  `modificado_nvl_pg` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `niveis_acessos_paginas`
--

INSERT INTO `niveis_acessos_paginas` (`id_nvl_pg`, `niveis_acesso_id`, `pagina_id`, `permissao`, `menu`, `ordem`, `criado_nvl_pg`, `modificado_nvl_pg`) VALUES
(5, 1, 8, 1, 1, 2, '2020-09-17 00:00:00', '2021-12-10 17:26:45'),
(6, 1, 7, 1, 1, 1, '2020-09-17 00:00:00', '2023-05-12 02:29:32'),
(12, 1, 11, 1, 2, 1, '2020-09-21 00:00:00', '2021-12-10 17:26:45'),
(13, 1, 12, 1, 2, 1, '2020-09-23 00:00:00', '2021-12-10 17:26:45'),
(14, 1, 13, 1, 2, 1, '2020-09-23 00:00:00', '2021-12-10 17:26:45'),
(15, 1, 14, 1, 2, 1, '2020-09-23 00:00:00', '2021-12-10 17:26:45'),
(16, 1, 15, 1, 2, 1, '2020-09-23 00:00:00', '2021-12-10 17:26:45'),
(17, 1, 16, 1, 2, 1, '2020-09-23 00:00:00', '2021-12-10 17:26:45'),
(18, 1, 17, 1, 2, 1, '2020-09-24 00:00:00', '2021-12-10 17:26:45'),
(19, 1, 18, 1, 2, 18, '2020-09-25 00:00:00', '2021-12-10 17:26:45'),
(25, 1, 19, 1, 2, 19, '2020-09-27 00:00:00', '2021-12-10 17:26:45'),
(26, 1, 20, 1, 2, 20, '2020-09-27 00:00:00', '2021-12-10 17:26:45'),
(27, 1, 21, 1, 2, 21, '2020-10-01 00:00:00', '2021-12-10 17:26:45'),
(28, 1, 22, 1, 2, 22, '2020-10-01 00:00:00', '2021-12-10 17:26:45'),
(29, 1, 23, 1, 2, 23, '2020-10-01 00:00:00', '2021-12-10 17:26:45'),
(30, 1, 24, 1, 2, 24, '2020-10-01 00:00:00', '2021-12-10 17:26:45'),
(34, 1, 25, 1, 2, 25, '2020-10-02 00:00:00', '2021-12-10 17:26:45'),
(35, 1, 26, 1, 2, 26, '2020-10-02 00:00:00', '2021-12-10 17:26:45'),
(36, 1, 27, 1, 2, 27, '2020-10-02 00:00:00', '2023-05-12 02:31:33'),
(37, 1, 28, 1, 2, 28, '2020-11-03 00:00:00', '2021-12-10 17:26:45'),
(46, 1, 29, 1, 2, 29, '2020-11-17 00:00:00', '2021-12-10 17:26:45'),
(73, 1, 2, 1, 2, 31, '2020-11-18 12:59:20', '2023-05-12 02:30:21'),
(74, 1, 3, 1, 2, 31, '2020-11-18 12:59:20', '2023-05-12 02:29:55'),
(75, 1, 4, 1, 2, 31, '2020-11-18 12:59:20', '2021-12-10 17:26:45'),
(76, 1, 5, 1, 2, 31, '2020-11-18 12:59:20', '2021-12-10 17:26:45'),
(77, 1, 9, 1, 2, 31, '2020-11-18 12:59:20', '2021-12-10 17:26:45'),
(78, 1, 10, 1, 2, 31, '2020-11-18 12:59:20', '2021-12-10 17:26:45'),
(404, 1, 30, 1, 2, 60, '2020-11-19 00:00:00', '2021-12-10 17:26:45'),
(405, 1, 31, 1, 2, 61, '2020-11-19 00:00:00', '2021-12-10 17:26:45'),
(406, 1, 32, 1, 2, 62, '2020-11-19 00:00:00', '2021-12-10 17:26:45'),
(407, 1, 33, 1, 2, 63, '2020-11-21 00:00:00', '2021-12-10 17:26:45'),
(408, 1, 34, 1, 2, 64, '2020-11-21 00:00:00', '2021-12-10 17:26:45'),
(409, 1, 35, 1, 2, 65, '2020-11-21 00:00:00', '2021-12-10 17:26:45'),
(410, 1, 36, 1, 2, 66, '2020-11-21 00:00:00', '2021-12-10 17:26:45'),
(411, 1, 37, 1, 2, 67, '2020-11-23 00:00:00', '2021-12-10 17:26:45'),
(412, 1, 38, 1, 2, 68, '2020-11-24 00:00:00', '2021-12-10 17:26:45'),
(413, 1, 39, 1, 2, 69, '2020-11-24 00:00:00', '2021-12-10 17:26:45'),
(414, 1, 40, 1, 2, 70, '2020-11-24 00:00:00', '2021-12-10 17:26:45'),
(415, 1, 41, 1, 2, 71, '2020-11-24 00:00:00', '2021-12-10 17:26:45'),
(451, 1, 77, 1, 2, 107, '2021-02-11 00:00:00', '2023-05-12 02:31:03'),
(663, 1, 93, 1, 1, 213, '2021-03-25 00:00:00', '2021-12-11 15:30:45'),
(664, 1, 94, 1, 2, 214, '2021-03-26 00:00:00', '2021-12-11 12:21:11'),
(665, 1, 95, 1, 2, 215, '2021-03-26 00:00:00', '2021-12-10 17:12:53'),
(669, 1, 99, 1, 1, 219, '2021-05-03 00:00:00', '2023-05-12 02:32:01'),
(670, 1, 100, 1, 2, 220, '2021-05-03 00:00:00', '2021-12-10 17:26:45'),
(679, 1, 109, 1, 1, 226, '2021-05-22 00:00:00', '2021-12-10 17:26:45'),
(686, 1, 116, 1, 2, 232, '2021-07-10 00:00:00', '2021-12-10 17:26:45'),
(687, 1, 117, 1, 2, 233, '2021-07-10 00:00:00', '2021-12-10 17:26:45'),
(688, 1, 118, 1, 2, 234, '2021-07-10 00:00:00', '2021-12-10 17:26:45'),
(689, 1, 119, 1, 2, 235, '2021-07-10 00:00:00', '2021-12-10 17:26:45'),
(690, 1, 120, 1, 2, 236, '2021-07-10 00:00:00', '2021-12-10 17:26:45'),
(691, 1, 121, 1, 2, 237, '2021-07-10 00:00:00', '2021-12-10 17:26:45'),
(836, 1, 129, 1, 2, 238, '2021-12-11 14:51:11', NULL),
(890, 1, 130, 1, 2, 239, '2021-12-11 21:49:34', NULL),
(891, 1, 131, 1, 2, 240, '2021-12-13 23:00:13', NULL),
(892, 1, 132, 1, 2, 241, '2021-12-14 23:05:56', NULL),
(893, 1, 133, 1, 2, 242, '2021-12-14 23:35:41', NULL),
(894, 1, 134, 1, 2, 243, '2021-12-16 09:57:37', '2021-12-16 09:58:17'),
(978, 1, 135, 1, 2, 244, '2021-12-17 21:43:15', '2021-12-17 21:45:20'),
(981, 1, 136, 1, 2, 245, '2021-12-19 14:09:52', '2021-12-19 14:12:16'),
(984, 1, 137, 1, 2, 246, '2021-12-19 19:03:33', NULL),
(987, 1, 138, 1, 2, 247, '2021-12-20 19:25:25', NULL),
(990, 1, 139, 1, 2, 248, '2021-12-20 20:38:11', '2021-12-20 20:38:30'),
(995, 1, 140, 1, 2, 249, '2021-12-31 16:14:36', NULL),
(1007, 2, 7, 1, 1, 1, '2023-05-11 20:39:54', '2023-05-12 02:29:32'),
(1008, 2, 93, 1, 1, 2, '2023-05-11 20:39:54', NULL),
(1009, 2, 94, 1, 2, 3, '2023-05-11 20:39:54', '2023-05-11 20:40:07'),
(1010, 2, 95, 1, 2, 4, '2023-05-11 20:39:54', '2023-05-11 20:40:07'),
(1022, 1, 153, 1, 2, 250, '2023-06-12 11:35:48', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `objeto_paginas`
--

CREATE TABLE `objeto_paginas` (
  `idobj` int(11) NOT NULL,
  `objeto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `objeto_paginas`
--

INSERT INTO `objeto_paginas` (`idobj`, `objeto`) VALUES
(1, 'Tela'),
(2, 'Botão'),
(3, 'Submenu');

-- --------------------------------------------------------

--
-- Estrutura para tabela `opcoes_menu`
--

CREATE TABLE `opcoes_menu` (
  `id` int(11) NOT NULL,
  `nome` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `opcoes_menu`
--

INSERT INTO `opcoes_menu` (`id`, `nome`) VALUES
(1, 'Ativo'),
(2, 'Inativo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `paginas`
--

CREATE TABLE `paginas` (
  `id_pg` int(11) NOT NULL,
  `icon` longtext DEFAULT NULL,
  `endereco_pg` varchar(520) NOT NULL,
  `nome_pg` varchar(220) NOT NULL,
  `menu_lateral` int(11) NOT NULL DEFAULT 2 COMMENT 'se o valor for 1: aparecer no menu lateral. Se o valor for 2: não aparecer',
  `objeto_id` int(11) DEFAULT NULL,
  `modulo_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ordem_menu` int(11) DEFAULT NULL,
  `criado_pg` datetime NOT NULL,
  `modificado_pg` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `paginas`
--

INSERT INTO `paginas` (`id_pg`, `icon`, `endereco_pg`, `nome_pg`, `menu_lateral`, `objeto_id`, `modulo_id`, `usuario_id`, `ordem_menu`, `criado_pg`, `modificado_pg`) VALUES
(2, NULL, 'pages/modulo/controle_de_acesso/cadastrar/cad_usuario', 'Cadastrar Usuário', 2, 1, 1, 1, NULL, '2020-09-16 00:00:00', '2023-05-12 02:30:21'),
(3, NULL, 'pages/modulo/controle_de_acesso/editar/edit_usuario', 'Editar Usuário', 2, 1, 1, 1, NULL, '2020-09-16 00:00:00', '2023-05-12 02:29:55'),
(4, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_usuario', 'proc_cad_usuario', 2, 2, 1, 1, NULL, '2020-09-16 00:00:00', '2021-12-08 23:14:56'),
(5, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_usuario', 'proc_edit_usuario', 2, 2, 1, 1, NULL, '2020-09-16 00:00:00', '2021-05-21 10:29:43'),
(7, 'fa fa-home', 'pages/modulo/home/home', 'Página inicial', 1, 1, 2, 1, 1, '2020-09-16 00:00:00', '2023-05-12 02:29:32'),
(8, 'fa fa-lock', 'pages/modulo/controle_de_acesso/controle_de_acesso', 'Controle de Acesso', 1, 1, 1, 1, 2, '2020-09-17 00:00:00', '2021-05-21 10:30:01'),
(9, NULL, 'pages/modulo/controle_de_acesso/apagar/proc_del_usuario', 'proc_del_usuario', 2, 2, 1, 1, NULL, '2020-09-18 00:00:00', '2021-12-08 16:33:10'),
(10, NULL, 'pages/modulo/controle_de_acesso/cadastrar/cad_unidade', 'Cadastrar Unidade', 2, 1, 1, 1, NULL, '2020-09-21 00:00:00', '2021-05-21 10:30:29'),
(11, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_unidade', 'proc_cad_unidade', 2, 2, 1, 1, NULL, '2020-09-23 00:00:00', '2021-05-21 10:30:40'),
(12, NULL, 'pages/modulo/controle_de_acesso/cadastrar/cad_grupo', 'Cadastrar Grupo', 2, 1, 1, 1, NULL, '2020-09-23 00:00:00', '2021-05-21 10:30:52'),
(13, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_grupo', 'proc_cad_grupo', 2, 2, 1, 1, NULL, '2020-09-23 00:44:00', '2021-05-21 10:31:05'),
(14, NULL, 'pages/modulo/controle_de_acesso/cadastrar/cad_cargo', 'Cadastrar Cargo', 2, 1, 1, 1, NULL, '2020-09-23 00:00:00', '2021-05-21 10:31:17'),
(15, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_cargo', 'proc_cad_cargo', 2, 2, 1, 1, NULL, '2020-09-23 00:00:00', '2021-05-21 10:31:33'),
(16, NULL, 'pages/modulo/controle_de_acesso/cadastrar/cad_permissao', 'Cadastrar Perfil de Acesso', 2, 1, 1, 1, NULL, '2020-09-23 00:00:00', '2021-05-21 10:46:00'),
(17, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_permissao', 'proc_cad_permissao', 2, 2, 1, 1, NULL, '2020-09-24 00:00:00', '2021-05-21 10:46:11'),
(18, NULL, 'pages/modulo/controle_de_acesso/listar/list_permissao', 'Permissões do Perfil de Acesso', 2, 1, 1, 1, NULL, '2020-09-25 00:00:00', '2021-07-09 21:40:02'),
(19, NULL, 'pages/modulo/controle_de_acesso/editar/edit_cargo', 'Editar Cargo', 2, 1, 1, 1, NULL, '2020-09-27 00:00:00', '2021-05-21 10:46:34'),
(20, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_cargo', 'proc_edit_cargo', 2, 2, 1, 1, NULL, '2020-09-27 00:00:00', '2021-12-08 16:32:39'),
(21, NULL, 'pages/modulo/controle_de_acesso/editar/edit_grupo', 'Editar Grupo', 2, 1, 1, 1, NULL, '2020-10-01 00:00:00', '2021-05-21 10:46:56'),
(22, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_grupo', 'proc_edit_grupo', 2, 2, 1, 1, NULL, '2020-10-01 00:00:00', '2021-05-21 10:47:08'),
(23, NULL, 'pages/modulo/controle_de_acesso/editar/edit_unidade', 'Editar unidade', 2, 1, 1, 1, NULL, '2020-10-01 00:00:00', '2021-05-21 10:47:18'),
(24, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_unidade', 'proc_edit_unidade', 2, 2, 1, 1, NULL, '2020-10-01 00:00:00', '2021-05-21 10:47:28'),
(25, NULL, 'pages/modulo/controle_de_acesso/editar/edit_perfil', 'Editar perfil', 2, 1, 1, 1, NULL, '2020-10-02 00:00:00', '2021-05-21 10:47:39'),
(26, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_perfil', 'proc_edit_perfil', 2, 2, 1, 1, NULL, '2020-10-02 00:00:00', '2021-05-21 10:47:50'),
(27, 'fa fa-code', 'pages/modulo/sistema/editar/edit_fluxo', 'Editar operação', 2, 1, 12, 1, NULL, '2020-10-02 00:00:00', '2023-05-12 02:31:33'),
(28, 'fa fa-code', 'pages/modulo/sistema/editar/processa/proc_edit_fluxo', 'Processa fluxo', 2, 2, 1, 1, NULL, '2020-11-03 00:00:00', '2021-05-21 10:48:11'),
(29, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_autoriza_desautoriza_permissao', 'processa autoriza e desautoriza permissões ', 2, 2, 1, 1, NULL, '2020-11-17 00:00:00', '2021-07-09 21:28:12'),
(30, NULL, 'pages/modulo/controle_de_acesso/editar/edit_senha_usuario', 'Redefinir senha', 2, 1, 1, 1, NULL, '2020-11-19 00:00:00', '2021-05-21 10:48:58'),
(31, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_senha_usuario', 'processa edita senha do usuário', 2, 2, 1, 1, NULL, '2020-11-19 00:00:00', '2021-07-09 21:28:57'),
(32, NULL, 'pages/modulo/controle_de_acesso/listar/list_hist_atualizacao', 'Histórico de atualização', 2, 1, 1, 1, NULL, '2020-11-19 00:00:00', '2021-07-09 21:40:40'),
(33, NULL, 'pages/modulo/controle_de_acesso/cadastrar/cad_departamento', 'Cadastrar departamento', 2, 1, 1, 1, NULL, '2020-11-21 00:00:00', '2021-05-21 10:53:15'),
(34, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_departamento', 'proc_cad_departamento', 2, 2, 1, 1, NULL, '2020-11-21 00:00:00', '2021-05-21 10:53:37'),
(35, NULL, 'pages/modulo/controle_de_acesso/editar/edit_departamento', 'Editar departamento', 2, 1, 1, 1, NULL, '2020-11-21 00:00:00', '2021-05-21 10:54:02'),
(36, NULL, 'pages/modulo/controle_de_acesso/editar/processa/proc_edit_departamento', 'proc_edit_departamento', 2, 2, 1, 1, NULL, '2020-11-21 00:00:00', '2021-05-21 10:54:32'),
(37, NULL, 'pages/modulo/controle_de_acesso/apagar/proc_del_cargo', 'Processa deletar cargo', 2, 2, 1, 1, NULL, '2020-11-23 00:00:00', '2021-05-21 10:54:44'),
(38, NULL, 'pages/modulo/controle_de_acesso/apagar/proc_del_departamento', 'Processa deleta departamento', 2, 2, 1, 1, NULL, '2020-11-24 00:00:00', '2021-05-21 10:55:22'),
(39, NULL, 'pages/modulo/controle_de_acesso/apagar/proc_del_grupo', 'processa deleta grupos', 2, 2, 1, 1, NULL, '2020-11-24 00:00:00', '2021-05-21 10:55:52'),
(40, NULL, 'pages/modulo/controle_de_acesso/apagar/proc_del_unidade', 'processa delete unidade', 2, 2, 1, 1, NULL, '2020-11-24 00:00:00', '2021-05-21 10:56:04'),
(41, NULL, 'pages/modulo/controle_de_acesso/apagar/proc_del_perfil', 'processa deleta perfil', 2, 2, 1, 1, NULL, '2020-11-24 00:00:00', '2021-05-21 10:56:17'),
(77, NULL, 'pages/modulo/controle_de_acesso/listar/list_operacoes', 'Operações do sistema', 2, 3, 1, 1, NULL, '2021-02-11 00:00:00', '2023-05-12 02:31:03'),
(93, 'fa fa-user', 'pages/modulo/meu_perfil/perfil', 'Meu perfil', 1, 1, 6, 1, 3, '2021-03-25 00:00:00', '2021-12-11 15:30:45'),
(94, 'fa fa-user', 'pages/modulo/meu_perfil/processa/proc_altera_senha', 'btn_proc_altera_senha', 2, 2, 6, 1, NULL, '2021-03-26 00:00:00', '2021-05-21 11:09:22'),
(95, 'fa fa-user', 'pages/modulo/meu_perfil/processa/proc_altera_usuario', 'btn_proc_altera_usuario', 2, 2, 6, 1, NULL, '2021-03-26 00:00:00', '2021-05-21 11:09:33'),
(99, 'fa fa-database', 'pages/modulo/importar/importar', 'Importação', 1, 1, 8, 1, 4, '2021-05-03 00:00:00', '2023-05-12 02:32:01'),
(100, 'fa fa-database', 'pages/modulo/importar/processa/proc_cad_cliente', 'proc_cad_cliente', 2, 2, 8, 1, NULL, '2021-05-03 00:00:00', '2021-05-21 10:58:06'),
(109, 'fa fa-code', 'pages/modulo/sistema/sistema', 'Sistema', 1, 1, 12, 1, 5, '2021-05-22 00:00:00', NULL),
(116, 'fa fa-code', 'pages/modulo/sistema/cadastrar/processa/proc_cad_modulo', 'proc_cad_modulo', 2, 2, 12, 1, NULL, '2021-05-22 00:00:00', NULL),
(117, 'fa fa-code', 'pages/modulo/sistema/editar/edit_modulo', 'Editar modulo', 2, 1, 12, 1, NULL, '2021-05-22 00:00:00', NULL),
(118, 'fa fa-code', 'pages/modulo/sistema/editar/processa/proc_edit_modulo', 'proc_edit_modulo', 2, 2, 12, 1, NULL, '2021-05-22 00:00:00', NULL),
(119, 'fa fa-code', 'pages/modulo/sistema/apagar/processa/proc_del_modulo', 'proc_del_modulo', 2, 2, 12, 1, NULL, '2021-05-22 00:00:00', NULL),
(120, 'fa fa-code', 'pages/modulo/sistema/apagar/processa/proc_del_fluxo', 'proc_del_fluxo', 2, 2, 12, 1, NULL, '2021-05-22 00:00:00', NULL),
(121, 'fa fa-code', 'pages/modulo/sistema/cadastrar/processa/proc_cad_fluxo', 'proc_cad_fluxo', 2, 2, 12, 1, NULL, '2021-05-22 00:00:00', NULL),
(129, NULL, 'pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_nova_permissao', 'btn_proc_cad_nova_permissao', 2, 2, 1, 1, NULL, '2021-12-11 14:51:11', NULL),
(130, NULL, 'pages/modulo/sistema/cadastrar/processa/proc_cad_personalizacao', 'btn_proc_cad_personalizacao', 2, 2, 12, 1, NULL, '2021-12-11 21:49:34', NULL),
(131, NULL, 'pages/modulo/sistema/cadastrar/processa/proc_cad_contrato', 'btn_proc_cad_contrato', 2, 2, 12, 1, NULL, '2021-12-13 23:00:13', NULL),
(132, NULL, 'pages/modulo/sistema/cadastrar/processa/proc_cad_plano', 'btn_proc_cad_plano', 2, 2, 12, 1, NULL, '2021-12-14 23:05:56', NULL),
(133, NULL, 'pages/modulo/sistema/cadastrar/processa/proc_cad_preco', 'btn_proc_cad_preco', 2, 2, 12, 1, NULL, '2021-12-14 23:35:41', NULL),
(134, NULL, 'pages/modulo/sistema/cadastrar/cad_contrato', 'Cadastrar contrato', 2, 1, 12, 1, NULL, '2021-12-16 09:57:37', '2021-12-16 09:58:17'),
(135, NULL, 'pages/modulo/sistema/editar/edit_contrato', 'Editar contrato', 2, 1, 12, 1, NULL, '2021-12-17 21:43:15', '2021-12-17 21:45:20'),
(136, NULL, 'pages/modulo/sistema/editar/processa/proc_edit_contrato', 'btn_proc_edit_contrato', 2, 2, 12, 1, NULL, '2021-12-19 14:09:52', '2021-12-19 14:12:16'),
(137, NULL, 'pages/modulo/sistema/editar/processa/proc_edit_anexo', 'btn_proc_edit_anexo', 2, 2, 12, 1, NULL, '2021-12-19 19:03:33', NULL),
(138, NULL, 'pages/modulo/sistema/cadastrar/processa/proc_cad_changelog', 'btn_proc_cad_changelog', 2, 2, 12, 1, NULL, '2021-12-20 19:25:25', NULL),
(139, NULL, 'pages/modulo/sistema/cadastrar/processa/proc_cad_versao', 'btn_proc_cad_versao', 2, 2, 12, 1, NULL, '2021-12-20 20:38:11', '2021-12-20 20:38:30'),
(140, NULL, 'pages/modulo/importar/processa/proc_import_usuario', 'btn_proc_import_usuario', 2, 2, 8, 1, NULL, '2021-12-31 16:14:36', NULL),
(153, NULL, 'pages/modulo/logout/sair', 'sair', 2, 2, 15, 1, 1, '2023-06-12 11:35:48', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `personalizacao_sistema`
--

CREATE TABLE `personalizacao_sistema` (
  `id` int(11) NOT NULL,
  `nome_sistema` varchar(200) NOT NULL,
  `site_sistema` varchar(200) NOT NULL,
  `nome_empresa` varchar(255) NOT NULL,
  `versao_atual_sistema` int(11) NOT NULL,
  `logo_sistema` varchar(255) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado` datetime NOT NULL,
  `modificado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `personalizacao_sistema`
--

INSERT INTO `personalizacao_sistema` (`id`, `nome_sistema`, `site_sistema`, `nome_empresa`, `versao_atual_sistema`, `logo_sistema`, `usuario_id`, `criado`, `modificado`) VALUES
(1, 'Site', 'https://www.companycodes.com.br', 'Company Codes', 1, '168634705764839d3143a76.png', 1, '2021-12-12 19:53:34', '2023-06-09 16:44:17');

-- --------------------------------------------------------

--
-- Estrutura para tabela `planos`
--

CREATE TABLE `planos` (
  `idplano` int(11) NOT NULL,
  `nome_plano` varchar(200) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_plano` datetime NOT NULL,
  `modifield_plano` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `planos`
--

INSERT INTO `planos` (`idplano`, `nome_plano`, `usuario_id`, `created_plano`, `modifield_plano`) VALUES
(1, 'Anual', 1, '2021-12-17 13:05:49', NULL),
(2, 'Mensal', 1, '2021-12-17 13:06:07', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `situacao_contrato`
--

CREATE TABLE `situacao_contrato` (
  `idsituacaocontrato` int(11) NOT NULL,
  `status_contrato` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `situacao_contrato`
--

INSERT INTO `situacao_contrato` (`idsituacaocontrato`, `status_contrato`) VALUES
(1, 'Ativo'),
(2, 'Inativo'),
(3, 'Cancelado');

-- --------------------------------------------------------

--
-- Estrutura para tabela `situacoes_menu`
--

CREATE TABLE `situacoes_menu` (
  `id_st_me` int(11) NOT NULL,
  `nome_st_me` varchar(100) NOT NULL,
  `cor_st_me` varchar(100) NOT NULL,
  `criado_st_me` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `situacoes_menu`
--

INSERT INTO `situacoes_menu` (`id_st_me`, `nome_st_me`, `cor_st_me`, `criado_st_me`) VALUES
(1, 'Ativo', 'text-success', '2020-09-25 00:00:00'),
(2, 'Inativo', 'text-danger', '2020-09-25 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `situacoes_permisoes`
--

CREATE TABLE `situacoes_permisoes` (
  `id_st_perm` int(11) NOT NULL,
  `nome_st_perm` varchar(100) NOT NULL,
  `cor_st_perm` varchar(100) NOT NULL,
  `criado_st_perm` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `situacoes_permisoes`
--

INSERT INTO `situacoes_permisoes` (`id_st_perm`, `nome_st_perm`, `cor_st_perm`, `criado_st_perm`) VALUES
(1, 'Ativo', 'text-success', '2020-09-25 00:00:00'),
(2, 'Inativo', 'text-danger', '2020-09-25 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `situacoes_usuarios`
--

CREATE TABLE `situacoes_usuarios` (
  `id_situacao` int(11) NOT NULL,
  `nome_situacao` varchar(50) NOT NULL,
  `cor_situacao` varchar(50) NOT NULL,
  `criado_situacao` datetime NOT NULL,
  `modificado_situacao` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `situacoes_usuarios`
--

INSERT INTO `situacoes_usuarios` (`id_situacao`, `nome_situacao`, `cor_situacao`, `criado_situacao`, `modificado_situacao`) VALUES
(1, 'Ativo', 'text-success', '2020-09-16 00:00:00', NULL),
(2, 'Inativo', 'text-danger', '2020-09-18 00:00:00', NULL),
(3, 'Senha resetada', 'text-danger', '2020-11-23 00:00:00', NULL),
(4, 'Senha expirada', 'text-danger', '2020-11-23 00:00:00', NULL),
(5, 'Conta e senha ativa', 'text-success', '2020-11-23 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `unidade`
--

CREATE TABLE `unidade` (
  `id_uni` int(11) NOT NULL,
  `nome_uni` varchar(250) NOT NULL,
  `sigla_uni` varchar(7) NOT NULL,
  `descricao_uni` mediumtext DEFAULT NULL,
  `grupo_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_uni` datetime NOT NULL,
  `modificado_uni` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `unidade`
--

INSERT INTO `unidade` (`id_uni`, `nome_uni`, `sigla_uni`, `descricao_uni`, `grupo_id`, `usuario_id`, `criado_uni`, `modificado_uni`) VALUES
(1, 'Unidade padrão', 'UP', 'Unidade do sistema', 1, 1, '2020-09-21 00:00:00', '2023-05-12 02:42:07');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_user` int(11) NOT NULL,
  `nome_user` varchar(220) NOT NULL,
  `email_user` varchar(220) NOT NULL,
  `login_user` varchar(220) NOT NULL,
  `senha_user` varchar(220) NOT NULL,
  `token` mediumtext DEFAULT NULL,
  `niveis_acesso_id` int(11) NOT NULL,
  `situacoes_usuario_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  `unidade_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `contrato_sistema_id` int(11) DEFAULT NULL,
  `anotacao` mediumtext DEFAULT NULL,
  `foto` varchar(200) DEFAULT NULL,
  `criado_user` datetime NOT NULL,
  `modificado_user` datetime DEFAULT NULL,
  `ult_token` datetime DEFAULT NULL,
  `ult_acesso` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id_user`, `nome_user`, `email_user`, `login_user`, `senha_user`, `token`, `niveis_acesso_id`, `situacoes_usuario_id`, `cargo_id`, `unidade_id`, `usuario_id`, `contrato_sistema_id`, `anotacao`, `foto`, `criado_user`, `modificado_user`, `ult_token`, `ult_acesso`) VALUES
(1, 'KALLEB ALVES BARBOSA', 'kallebalves@gmail.com', 'kalleb.barbosa', '$2y$10$1FhR3R.TTgKN0w1irpmpj.oNXWWQGHbb6cvzlZ35KNjzs1i.H9GZi', '63c8103589ee10d4e50077f7a63677a29d6eb425888a05cab29870703a44e3a4', 1, 5, 1, 1, 1, NULL, 'Usuário máster do sistema', NULL, '2021-12-17 18:42:31', '2023-06-12 10:38:06', '2023-06-12 10:38:06', '2023-06-12 11:37:19'),
(3, 'POLICLINICA', 'policlinica@gmail.com', 'policlinica', '$2y$10$ftGRuK38LtLCjujaMdcN1uIHaCh8tjZrTVf1zR17L1okBNahUsZ2y', '75D3BABAA34EB94D524AFBF1E92CD3E86456B6FAF7413A00B90BC4B86809C883', 1, 5, 14, 1, 1, 1, '', NULL, '2023-05-11 20:33:37', '2023-05-11 20:38:30', '2023-06-12 11:25:47', '2023-05-12 13:05:28'),
(4, 'ANDRÉ LUIZ MARQUES', 'andre.marques@policlinica.com.br', 'andre.marques', '$2y$10$Dj1QwKFxQ4WHongP2QaYk.y01APcvy0lPbr2TYZ00PYKuXm70LAB6', '771BF4291504F5F2BA8D1A8AE4FF539A800C3833357185B6DE77A0239190DFCA', 2, 5, 14, 1, 3, 1, '', NULL, '2023-05-11 20:42:34', '2023-05-11 20:43:19', '2023-06-12 11:25:47', '2023-05-12 11:34:45');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios_contrato`
--

CREATE TABLE `usuarios_contrato` (
  `id` int(11) NOT NULL,
  `situacao` varchar(50) NOT NULL,
  `qtd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `usuarios_contrato`
--

INSERT INTO `usuarios_contrato` (`id`, `situacao`, `qtd`) VALUES
(1, '1', 1),
(2, '5', 5),
(3, '10', 10),
(4, '15', 15),
(5, '20', 20),
(6, '25', 25),
(7, '30', 30),
(8, '35', 35),
(9, '40', 40),
(10, '45', 45),
(11, '50', 50),
(12, 'Ilimitado', 999999);

-- --------------------------------------------------------

--
-- Estrutura para tabela `versoes`
--

CREATE TABLE `versoes` (
  `idversao` int(11) NOT NULL,
  `versao` varchar(255) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_versao` datetime NOT NULL,
  `modifield_versao` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `versoes`
--

INSERT INTO `versoes` (`idversao`, `versao`, `usuario_id`, `created_versao`, `modifield_versao`) VALUES
(1, '0.0.1', 1, '2021-12-20 05:37:06', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `auth_token`
--
ALTER TABLE `auth_token`
  ADD PRIMARY KEY (`idToken`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id_cargo`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `departamento` (`departamento`);

--
-- Índices de tabela `categoria_versao`
--
ALTER TABLE `categoria_versao`
  ADD PRIMARY KEY (`idcatversao`);

--
-- Índices de tabela `changelog`
--
ALTER TABLE `changelog`
  ADD PRIMARY KEY (`idchangelog`),
  ADD KEY `categoria_versao_id` (`categoria_versao_id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `versoes_id` (`versoes_id`);

--
-- Índices de tabela `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`idchat`),
  ADD KEY `from_user` (`from_user`),
  ADD KEY `to_user` (`to_user`);

--
-- Índices de tabela `contrato_sistema`
--
ALTER TABLE `contrato_sistema`
  ADD PRIMARY KEY (`idcontratosistema`),
  ADD KEY `situacao_contrato_id` (`situacao_contrato_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`id_depar`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `enquete`
--
ALTER TABLE `enquete`
  ADD PRIMARY KEY (`idenquete`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `enquete_rating`
--
ALTER TABLE `enquete_rating`
  ADD PRIMARY KEY (`idrating`);

--
-- Índices de tabela `evento_senha`
--
ALTER TABLE `evento_senha`
  ADD PRIMARY KEY (`id_eventoSenha`);

--
-- Índices de tabela `grupo`
--
ALTER TABLE `grupo`
  ADD PRIMARY KEY (`id_gru`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `grupo_pai_id` (`grupo_pai_id`);

--
-- Índices de tabela `hist_senha`
--
ALTER TABLE `hist_senha`
  ADD PRIMARY KEY (`id_histSenha`),
  ADD KEY `operador` (`operador`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `modelos_plano`
--
ALTER TABLE `modelos_plano`
  ADD PRIMARY KEY (`idmodeloplano`),
  ADD KEY `plano_id` (`plano_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`id_mod`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `niveis_acessos`
--
ALTER TABLE `niveis_acessos`
  ADD PRIMARY KEY (`id_nvl`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `niveis_acessos_paginas`
--
ALTER TABLE `niveis_acessos_paginas`
  ADD PRIMARY KEY (`id_nvl_pg`),
  ADD KEY `niveis_acesso_id` (`niveis_acesso_id`),
  ADD KEY `menu` (`menu`),
  ADD KEY `permissao` (`permissao`),
  ADD KEY `pagina_id` (`pagina_id`);

--
-- Índices de tabela `objeto_paginas`
--
ALTER TABLE `objeto_paginas`
  ADD PRIMARY KEY (`idobj`);

--
-- Índices de tabela `opcoes_menu`
--
ALTER TABLE `opcoes_menu`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `paginas`
--
ALTER TABLE `paginas`
  ADD PRIMARY KEY (`id_pg`),
  ADD KEY `modulo_id` (`modulo_id`),
  ADD KEY `objeto_id` (`objeto_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `personalizacao_sistema`
--
ALTER TABLE `personalizacao_sistema`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`idplano`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `situacao_contrato`
--
ALTER TABLE `situacao_contrato`
  ADD PRIMARY KEY (`idsituacaocontrato`);

--
-- Índices de tabela `situacoes_menu`
--
ALTER TABLE `situacoes_menu`
  ADD PRIMARY KEY (`id_st_me`);

--
-- Índices de tabela `situacoes_permisoes`
--
ALTER TABLE `situacoes_permisoes`
  ADD PRIMARY KEY (`id_st_perm`);

--
-- Índices de tabela `situacoes_usuarios`
--
ALTER TABLE `situacoes_usuarios`
  ADD PRIMARY KEY (`id_situacao`);

--
-- Índices de tabela `unidade`
--
ALTER TABLE `unidade`
  ADD PRIMARY KEY (`id_uni`),
  ADD KEY `grupo_id` (`grupo_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `contrato_sistema_id` (`contrato_sistema_id`),
  ADD KEY `cargo_id` (`cargo_id`),
  ADD KEY `niveis_acesso_id` (`niveis_acesso_id`),
  ADD KEY `situacoes_usuario_id` (`situacoes_usuario_id`),
  ADD KEY `unidade_id` (`unidade_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `usuarios_contrato`
--
ALTER TABLE `usuarios_contrato`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `versoes`
--
ALTER TABLE `versoes`
  ADD PRIMARY KEY (`idversao`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `auth_token`
--
ALTER TABLE `auth_token`
  MODIFY `idToken` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT de tabela `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id_cargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `categoria_versao`
--
ALTER TABLE `categoria_versao`
  MODIFY `idcatversao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `changelog`
--
ALTER TABLE `changelog`
  MODIFY `idchangelog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `idchat` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `contrato_sistema`
--
ALTER TABLE `contrato_sistema`
  MODIFY `idcontratosistema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `departamento`
--
ALTER TABLE `departamento`
  MODIFY `id_depar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `enquete`
--
ALTER TABLE `enquete`
  MODIFY `idenquete` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `enquete_rating`
--
ALTER TABLE `enquete_rating`
  MODIFY `idrating` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `evento_senha`
--
ALTER TABLE `evento_senha`
  MODIFY `id_eventoSenha` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `grupo`
--
ALTER TABLE `grupo`
  MODIFY `id_gru` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `hist_senha`
--
ALTER TABLE `hist_senha`
  MODIFY `id_histSenha` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `modelos_plano`
--
ALTER TABLE `modelos_plano`
  MODIFY `idmodeloplano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `modulos`
--
ALTER TABLE `modulos`
  MODIFY `id_mod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `niveis_acessos`
--
ALTER TABLE `niveis_acessos`
  MODIFY `id_nvl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `niveis_acessos_paginas`
--
ALTER TABLE `niveis_acessos_paginas`
  MODIFY `id_nvl_pg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1023;

--
-- AUTO_INCREMENT de tabela `objeto_paginas`
--
ALTER TABLE `objeto_paginas`
  MODIFY `idobj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `opcoes_menu`
--
ALTER TABLE `opcoes_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `paginas`
--
ALTER TABLE `paginas`
  MODIFY `id_pg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT de tabela `personalizacao_sistema`
--
ALTER TABLE `personalizacao_sistema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `idplano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `situacao_contrato`
--
ALTER TABLE `situacao_contrato`
  MODIFY `idsituacaocontrato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `situacoes_menu`
--
ALTER TABLE `situacoes_menu`
  MODIFY `id_st_me` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `situacoes_permisoes`
--
ALTER TABLE `situacoes_permisoes`
  MODIFY `id_st_perm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `situacoes_usuarios`
--
ALTER TABLE `situacoes_usuarios`
  MODIFY `id_situacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `unidade`
--
ALTER TABLE `unidade`
  MODIFY `id_uni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `usuarios_contrato`
--
ALTER TABLE `usuarios_contrato`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `versoes`
--
ALTER TABLE `versoes`
  MODIFY `idversao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `auth_token`
--
ALTER TABLE `auth_token`
  ADD CONSTRAINT `auth_token_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
