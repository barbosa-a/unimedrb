<?php

if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    $protocol = 'https';
} else {
    $protocol = 'http';
}

$url_host = filter_input(INPUT_SERVER, 'HTTP_HOST');
define('pg', "$protocol://$url_host/login");

define('nomeSistema', 'Login');