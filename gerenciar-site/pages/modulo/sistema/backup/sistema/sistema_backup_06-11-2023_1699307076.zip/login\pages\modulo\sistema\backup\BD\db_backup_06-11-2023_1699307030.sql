DROP TABLE IF EXISTS auth_token;
CREATE TABLE `auth_token` (
  `idToken` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `token` mediumtext NOT NULL,
  `criado_token` datetime NOT NULL,
  PRIMARY KEY (`idToken`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `auth_token_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO auth_token VALUES("1", "1", "D2195E56EE2C0921029FA71A9340D78751F00CE0B5AE0ED8F4B6D05F818AFF56", "2023-04-26 18:09:09");
INSERT INTO auth_token VALUES("2", "1", "CC808C0F36BFBF1540925CFD9D95FAACF76476624CCD6961CF544FF309FECD37", "2023-04-26 19:09:14");
INSERT INTO auth_token VALUES("3", "1", "D846F61095826181008E3335A18EFEE058C9AD8431D9F5EFC5118C5E6E02E832", "2023-04-26 20:11:14");
INSERT INTO auth_token VALUES("4", "1", "C6A25E7AEA6086DA9E546EB1BD6AABE67C369AC6306C172BBCAC19895553E4F7", "2023-04-26 22:20:54");
INSERT INTO auth_token VALUES("5", "1", "BB4071349917A670CF1DA251156977EC750742168A09F1BE72FDC4C3321BB906", "2023-04-27 13:49:08");
INSERT INTO auth_token VALUES("6", "1", "FB2765924842A2839AB70113BE1140205A684023DEDF7F1746195C6C2FBC97F0", "2023-04-29 11:20:51");
INSERT INTO auth_token VALUES("7", "1", "82AE78ECAFECABCCD6420C62DCEB6C27D2270B8AB0F2CE214B54E1587210ADA2", "2023-04-29 15:15:26");
INSERT INTO auth_token VALUES("8", "1", "936C32ADE544DDE8FCA5E2AA85480C740CE98434F74E490DC4A790685DA54451", "2023-04-30 17:25:24");
INSERT INTO auth_token VALUES("9", "1", "B8398C752773208AB99FD1DA78D9590AD5BC2EABF3443785884C9F4BB49914E4", "2023-04-30 21:53:24");
INSERT INTO auth_token VALUES("10", "1", "12D1D1E830BDB304D92C18E13717D3A3746CE184FD0B099DA7B8F26F09E4A130", "2023-04-30 23:02:27");
INSERT INTO auth_token VALUES("11", "1", "E5FFC1DD1EDCA4C950D72DEC363797767A5A70DE3BBE4CC04040320F73BF1275", "2023-05-01 00:09:04");
INSERT INTO auth_token VALUES("12", "1", "87B6D36946E8CA1F440334F17D5B8E655F8FBAB397CC77A97DBAEB3B3187FEB0", "2023-05-02 09:52:49");
INSERT INTO auth_token VALUES("13", "1", "5181AA0FC73E6B5D4CAB9B329C967F87E4B271A0E1830D18D58406DA32A54A52", "2023-05-02 14:12:19");
INSERT INTO auth_token VALUES("14", "1", "CCD41A468A1E4DEC8FB9D883B69B0AFACD743FD0DD99E7A5A561176C9C4757AF", "2023-05-02 15:21:01");
INSERT INTO auth_token VALUES("15", "1", "FE17575137A450AE09AA809E805306CCCF04BEF58B8EDC742971EEFCD41F2A56", "2023-05-03 17:51:31");
INSERT INTO auth_token VALUES("16", "1", "EC06D7792DD2C99DBED1573A6A22F87A328A0FAF02E524F2295DC158F3693B2A", "2023-05-03 18:58:38");
INSERT INTO auth_token VALUES("17", "1", "B6AB7B86BCE00B05AE790365CB449FDB3B1C913FD823BB4FE7C32C2552237158", "2023-05-03 20:01:38");
INSERT INTO auth_token VALUES("18", "1", "63621778563AFE1671F25EF7A88ABF417A9BB73250C02E69A7114CD65FB96FE8", "2023-05-03 21:13:15");
INSERT INTO auth_token VALUES("19", "1", "A98F1104B8501A41B909F4F4C0D60AD09E6C7BE230F75D853D811F40E49DA87C", "2023-05-03 22:13:18");
INSERT INTO auth_token VALUES("20", "1", "EC23B98C78682D8447D4C23DF64ACC344BC29A51414941CDF2041D8A8B177FF6", "2023-05-05 17:48:47");
INSERT INTO auth_token VALUES("21", "1", "F2A644421734CCC54624F9C61482B764045F7F4F15D76366E8A6EB27851BDD18", "2023-05-05 19:01:45");
INSERT INTO auth_token VALUES("22", "1", "C3518B19868945945D5A5A6AE06C5374B27C81CED46A37AF0A2374141B41DA5E", "2023-05-05 20:01:58");
INSERT INTO auth_token VALUES("23", "1", "F8B923402A299A1CF1C6F4AB6581579D1C66A4498C442C0472576A09C118D73C", "2023-05-05 21:02:09");
INSERT INTO auth_token VALUES("24", "1", "5228DF91C7917A0318E498B000EF9B0660B644253737CE40709EB892043C6BF4", "2023-05-05 22:02:55");
INSERT INTO auth_token VALUES("25", "1", "9261B931588E80B72C55421C254A0A9F36F794C749565D12A8C0E80B073AD956", "2023-05-06 15:11:46");
INSERT INTO auth_token VALUES("26", "1", "A56333E27FFE9F9A26C8A916607A807E77638C456161030332EC466C2E72B6EF", "2023-05-06 16:17:14");
INSERT INTO auth_token VALUES("27", "1", "4206171457CD2A85C0C9D458EC94DF62B6845B1649464F6B8F39BE122955D8D2", "2023-05-06 17:23:04");
INSERT INTO auth_token VALUES("28", "1", "7108D67B4A6A8CA1A9DA01CA991AFF7823BBCE0CFEA8F591F4591ED027B52172", "2023-05-06 19:40:56");
INSERT INTO auth_token VALUES("29", "1", "D6278F219DA9CCCA714623DB5F26DBB6F9B1806A61CDC4D320D8413C83C11194", "2023-05-06 20:41:11");
INSERT INTO auth_token VALUES("30", "1", "71A2A660B4FB905732CFB9C46790A184EF54FA1A7ECEE1AA5DD16A8094C2570C", "2023-05-06 21:45:13");
INSERT INTO auth_token VALUES("31", "1", "1704CFAB5AA6964E688AAE9FAEF192E51743F34A1435550446C394FB65D70F7D", "2023-05-07 11:18:43");
INSERT INTO auth_token VALUES("32", "1", "4F5F3D8C56364738F5581888C63CF406267B23B0B3DC71F65994F553A0556C50", "2023-05-07 17:23:00");
INSERT INTO auth_token VALUES("33", "1", "49E1901F1AC3A50BDC8649C2AA37D233F047AD47CB6B0D522AB37876AF308926", "2023-05-07 18:48:16");
INSERT INTO auth_token VALUES("34", "1", "3E2285BA1240651E44454D6FAB3FF41A413336FAE5CE0281EDC9C9227BD6192B", "2023-05-07 19:50:29");
INSERT INTO auth_token VALUES("35", "1", "7293513F4C5C6D5707F2B834757A209D6836ACC838277C96B99E229290094D5C", "2023-05-07 20:50:57");
INSERT INTO auth_token VALUES("36", "1", "0E9AD6A0FB02FD84FECF5AEC60E342F8E42AAFA09AD0A238877745B4BF2BC4C6", "2023-05-07 21:51:27");
INSERT INTO auth_token VALUES("37", "1", "2B9207F2BAA9CE7352A187F43FF2DF307C92FC1B6ADBBCB493268E4EC86256CF", "2023-05-07 23:07:13");
INSERT INTO auth_token VALUES("38", "1", "FB6BE3C049F60DAE8147B94415D55CDCDE73404C9F4CCE4203410C6862C6FFCD", "2023-05-08 17:50:06");
INSERT INTO auth_token VALUES("39", "1", "24F5AFA209849AE09208A9C1C0C7D6E95F1910A4415637FCB0AD6C6CBDE33293", "2023-05-08 19:10:46");
INSERT INTO auth_token VALUES("40", "1", "73FE584F356AD4F74C96E21E0DEA2098F4EF5372C1DE03A7B04F4BDD86FD8915", "2023-05-08 21:23:33");
INSERT INTO auth_token VALUES("41", "1", "FB2B5A1408DCD023B041E4CD16B50632073A68CC41E8D58FFFA62149997C47BF", "2023-05-10 18:51:53");
INSERT INTO auth_token VALUES("42", "1", "FF51EC3628E875D65111484002522D41D2FD8CD510401B86CAB2A0771A131173", "2023-05-10 20:02:00");
INSERT INTO auth_token VALUES("43", "1", "16FF3913EC16AF44B4F5C6D00521CF9A4277E2291F9337FA5790EBFDE2605E1D", "2023-05-10 21:04:56");
INSERT INTO auth_token VALUES("44", "1", "B445988F740D19F58560663DAAF4D4A52CC3202FAF06F53E9092A2D82D3638EC", "2023-05-10 22:28:51");
INSERT INTO auth_token VALUES("45", "1", "AF402F99EC333F44B8204D996FA729906E12EC81F70F148896904383CD1B2B7E", "2023-05-11 20:21:55");
INSERT INTO auth_token VALUES("46", "1", "77DC223E81AACE9DCCFF7530830F0F1567817F04B9239E1F84627C49CB2E8C11", "2023-05-12 02:24:59");
INSERT INTO auth_token VALUES("49", "1", "CB9CBE7D04F42B3D966942DF83968E4A12EFB2EDE72585CD368AD9EEAD11E9FE", "2023-05-12 12:56:39");
INSERT INTO auth_token VALUES("52", "1", "44DC2B99C66E5B8224EBE4E402AEC37DDB37951F24C5EC2863BC1B1F054D4715", "2023-05-16 07:43:46");
INSERT INTO auth_token VALUES("55", "1", "FE3B6336AF1BBBA44271F7C410F650E0A9B71A0E5C0D5C59EC6F72BDC755E347", "2023-05-16 08:43:56");
INSERT INTO auth_token VALUES("58", "1", "97A893FF54952362A207D820C84960C430B709EC5E691B5E2AAC089729A0FCC9", "2023-05-16 10:59:26");
INSERT INTO auth_token VALUES("61", "1", "838013BB3DE21B058E0518E81198D37C9AE4E79F86CF081C5104C1E25AB4414B", "2023-05-17 09:01:48");
INSERT INTO auth_token VALUES("64", "1", "FEC4703C60500308D7C888B7827954FE843CC156BCDCD16BBB954442B848D9C2", "2023-05-17 10:04:14");
INSERT INTO auth_token VALUES("67", "1", "E491C2EA72880D457E5C4854EAE300617EB0389977E2EE74D28DAEBB8DFF86C5", "2023-05-17 11:11:07");
INSERT INTO auth_token VALUES("70", "1", "B178E63335CE37D9B2DBCC9DB47889E54741DA4DD67A39CF55CD5B67846C24E6", "2023-05-17 12:32:45");
INSERT INTO auth_token VALUES("73", "1", "4C613EA21D7614A6C71C9C399DFD3E71775D5534294F55346DE150C66AE1F1BE", "2023-05-22 09:32:04");
INSERT INTO auth_token VALUES("76", "1", "64DF50B543264B83DF4A6548A1CE8B0189C0F0FEE4DAB7BBEE040A9DC6071BE6", "2023-05-23 07:32:58");
INSERT INTO auth_token VALUES("79", "1", "E0C5FB0D29128DB606C6899D35018E7742BFCDDC41805B9F9CF220FB2267E4D4", "2023-05-25 08:52:26");
INSERT INTO auth_token VALUES("82", "1", "9ED96D321D782D21793657C6D2C143A3CFAA5F2A11BC10872AD015A6CDEC1239", "2023-05-25 10:33:30");
INSERT INTO auth_token VALUES("85", "1", "1E0C362C9218E31B0D45F605B061412107651854F4A282B93FA19F1579351214", "2023-05-25 11:46:50");
INSERT INTO auth_token VALUES("88", "1", "38DBEDB6F4A9C51316CFA7C6F0C1948A759C29B59B88636208FF503D2368F2E1", "2023-05-26 08:54:30");
INSERT INTO auth_token VALUES("91", "1", "EE23A9F47604B1CFE5EAEAE94FAC3CDDBE427D9984E1117B8A75F8DDEC23E0B1", "2023-05-26 09:55:08");
INSERT INTO auth_token VALUES("94", "1", "07BAFD532A7ABD1A186D671D0F9C30945F5F21C1E7EC3C04036C841C58F798C8", "2023-05-27 14:06:41");
INSERT INTO auth_token VALUES("97", "1", "B77372A62F98F36AB50D38A37C26DCBAABCF6906D882DB755EA2ACCD61DF53E0", "2023-05-27 15:10:00");
INSERT INTO auth_token VALUES("100", "1", "D502148B06B24591EA68EB7931CA2545601220D31765579B7A387444E1D751F9", "2023-05-27 16:35:41");
INSERT INTO auth_token VALUES("103", "1", "DEE4A8F51F75A6575C09EF0B208CB1C9B6041990D27EB82A98BC0A26683E27FC", "2023-05-27 17:37:03");
INSERT INTO auth_token VALUES("106", "1", "48D6902E8DEF067B6530DBF62E97C982EA89F9EED452C16B57DF0891D72B7A45", "2023-05-27 18:41:03");
INSERT INTO auth_token VALUES("109", "1", "8D4DF44D5FEF121E4FC9834EF43AE3566C06109E53ACA3C6034CCABB65C892B9", "2023-05-28 09:30:06");
INSERT INTO auth_token VALUES("112", "1", "4978B749B27F9E35D501B8A9F5093C015CAA9B5FBA9D9755C4452489DD818587", "2023-05-28 10:49:12");
INSERT INTO auth_token VALUES("115", "1", "FAF9F8E0811195FB3A3ED0BF73F7A08F1B3F32894A1886ECA18AC34A5883F800", "2023-05-28 11:51:57");
INSERT INTO auth_token VALUES("118", "1", "2BA90C4FB1460F585F91676E7FD98528A764D823F87EFE443DC0F713AC09C6ED", "2023-05-28 19:24:53");
INSERT INTO auth_token VALUES("121", "1", "1678E2695491ED760DF097EC41EADC5D764B2FB5ECF5BC434ACC4FBB26087FA4", "2023-05-28 20:28:00");
INSERT INTO auth_token VALUES("124", "1", "241A4852FAAD2D147ECD86A206F4D2603EAD5AC67905CD53747AB745458E3734", "2023-05-28 21:28:25");
INSERT INTO auth_token VALUES("127", "1", "62461F2D4C4D3B83AD2A4A54C1464D0B48FF9FB548BE230CBA3C358AD0CA0BA7", "2023-06-09 16:28:56");
INSERT INTO auth_token VALUES("130", "1", "BA40BB4B926C3F21698FF91E9293D658DE89D9683628C59BEFE093E720A8B181", "2023-06-12 10:25:06");
INSERT INTO auth_token VALUES("135", "1", "391D99CA2223CD2CEDD4D2A8CB5A0942A5666F64669F05B164685E1BAA85860A", "2023-10-28 10:12:23");
INSERT INTO auth_token VALUES("136", "1", "0756F8B40E485FFD0C5A2B81A2C30554141AFB2D009DFA47829D9DE3733FC0EE", "2023-10-28 12:13:14");
INSERT INTO auth_token VALUES("137", "1", "B5C7C9915A466A35411A30D5EC62B27FC52E3B31749E711F09AC94DC8028D374", "2023-10-28 15:23:23");
INSERT INTO auth_token VALUES("138", "1", "197760585172C9E42D8AE6354398AF446502E33A0BDF8B3C3C735BD3320C8006", "2023-10-28 17:57:14");
INSERT INTO auth_token VALUES("139", "1", "C267C7C0554BA29247CB0E6E2114C74703A67415E1A44E3BEB37A6B50CA75F19", "2023-10-29 10:56:24");
INSERT INTO auth_token VALUES("140", "1", "92145BF9107B48D7CD090FF8CCE68DC28567D94F5A7A90AB9028E56967EDA3F1", "2023-10-29 12:00:06");
INSERT INTO auth_token VALUES("141", "1", "B3EC2A1E4DDE3567997665CBC42CC95089A649614B463B03F74347B656928AD6", "2023-10-29 19:20:36");
INSERT INTO auth_token VALUES("142", "1", "EAAA6161B2E933C42A61DB4BAF02A0C3AE74A5039A9B384F54EC24DD51235E84", "2023-11-04 10:59:55");
INSERT INTO auth_token VALUES("143", "1", "1F58D7431DA6088A8F4E0576990CE2F44FA787F2005250DA8636C1C38EC76794", "2023-11-04 13:09:42");
INSERT INTO auth_token VALUES("144", "1", "30E9A7A9F8B2BE402784F50BFB3473139B82CD884304EA65AC06DA733CA2B156", "2023-11-04 14:10:27");
INSERT INTO auth_token VALUES("145", "1", "10693EEF20E40CFCFDDE81D70DDD07E34CCA5B47A63823F7F2BE0DDCFD639CBD", "2023-11-05 13:04:04");
INSERT INTO auth_token VALUES("146", "1", "25A2EEC26CC287323DD79663858386B0CC41C36A063F47661E3E89AB1EF6C807", "2023-11-05 14:05:52");
INSERT INTO auth_token VALUES("147", "1", "F71CFE14C36BA4463D682A3FE06C3D75C8CB14D58B32CF2772D37A18CAF69D23", "2023-11-05 15:06:45");
INSERT INTO auth_token VALUES("148", "1", "C31C2BD70EB71CE55E2538ECA55B046031904BFC1241C7FCE6EF43AD706715CB", "2023-11-05 16:37:23");
INSERT INTO auth_token VALUES("149", "1", "3E7BDDF0906565899FDD1A3231EEC9337100BBC7F62B853F0F1ABD1903583D4E", "2023-11-06 13:50:13");
INSERT INTO auth_token VALUES("150", "1", "719DAC63A00F8C6BA303ADF78FD9E72F81F55337884E3AF54A90736FE387E976", "2023-11-06 15:12:04");
INSERT INTO auth_token VALUES("151", "1", "0F19AF42FFF865440FD332BF6782F4ABAEC094E443F471916FBEAA611CF5C7BA", "2023-11-06 16:25:13");
DROP TABLE IF EXISTS cargo;
CREATE TABLE `cargo` (
  `id_cargo` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cargo` varchar(255) NOT NULL,
  `departamento` int(11) NOT NULL,
  `descricao_cargo` mediumtext DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_cargo` datetime NOT NULL,
  `modificado_cargo` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cargo`),
  KEY `usuario_id` (`usuario_id`),
  KEY `departamento` (`departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO cargo VALUES("1", "Front-end Developer", "8", "Front-end Developer", "1", "2020-09-21 00:00:00", "2021-12-17 18:56:48");
INSERT INTO cargo VALUES("12", "Gerente financeiro", "5", "", "1", "2021-07-13 23:11:44", "2021-12-17 18:52:27");
INSERT INTO cargo VALUES("14", "Administrador de sistemas", "8", "", "1", "2021-12-17 18:54:26", "");
DROP TABLE IF EXISTS categoria_versao;
CREATE TABLE `categoria_versao` (
  `idcatversao` int(11) NOT NULL AUTO_INCREMENT,
  `icone` varchar(100) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `mudanca` varchar(200) NOT NULL,
  `desc_mudanca` text NOT NULL,
  `created_mudanca` datetime NOT NULL,
  PRIMARY KEY (`idcatversao`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO categoria_versao VALUES("1", "fa fa-check bg-primary", "Adicionado", "Novas funcionalidades", "Added/Adicionado para novas funcionalidades.", "2021-12-20 01:42:07");
INSERT INTO categoria_versao VALUES("2", "fa fa-code bg-info", "Modificado", "Mudanças em funcionalidades existentes", "Changed/Modificado para mudanças em funcionalidades existentes.", "2021-12-20 01:42:07");
INSERT INTO categoria_versao VALUES("3", "fa fa-exclamation-triangle bg-warning", "Obsoleto", "Removidas das próximas versões", "Deprecated/Obsoleto para funcionalidades estáveis que foram removidas das próximas versões.", "2021-12-20 01:42:07");
INSERT INTO categoria_versao VALUES("4", "fa fa-times bg-danger", "Removido", "Funcionalidades removidas desta versão", "Removed/Removido para funcionalidades removidas desta versão.", "2021-12-20 01:42:07");
INSERT INTO categoria_versao VALUES("5", "fa fa-bug bg-success", "Corrigido", "Correção de bug", "Fixed/Consertado para qualquer correção de bug.", "2021-12-20 01:42:07");
INSERT INTO categoria_versao VALUES("6", "fa fa-key bg-gray", "Segurança", "Atualização de segurança", "Security/Segurança para incentivar usuários a atualizarem em caso de vulnerabilidades.", "2021-12-20 01:42:07");
DROP TABLE IF EXISTS changelog;
CREATE TABLE `changelog` (
  `idchangelog` int(11) NOT NULL AUTO_INCREMENT,
  `versoes_id` int(11) NOT NULL,
  `categoria_versao_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `descricao` longtext NOT NULL,
  `created` datetime NOT NULL,
  `modifield` datetime DEFAULT NULL,
  PRIMARY KEY (`idchangelog`),
  KEY `categoria_versao_id` (`categoria_versao_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `versoes_id` (`versoes_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO changelog VALUES("1", "1", "1", "1", "Adicionado submenu contrato do modulo sistema", "2021-12-19 23:47:19", "");
INSERT INTO changelog VALUES("2", "1", "1", "1", "Adicionado botão editar do submenu contrato do modulo sistema.", "2021-12-19 23:56:32", "");
INSERT INTO changelog VALUES("3", "1", "1", "1", "Adicionado o botão para atualizar o anexo do contrato no card de anexos do contrato.", "2021-12-19 23:58:32", "");
INSERT INTO changelog VALUES("4", "1", "2", "1", "Realizada a integração do contrato do cliente na validação do login. Permitindo somente o acesso ao sistema usuários vinculados a um contrato previamente cadastrado.", "2021-12-20 00:02:16", "");
INSERT INTO changelog VALUES("5", "1", "2", "1", "Criada as seguintes validações de login no arquivo valida_login.php: <br>\r\n1. Validação da situação (Ativo, Inativo ou Cancelado) do contrato. <br>\r\n2. Validação de senhas expiradas no período de 30 dias. <br>\r\n3. Verificar se o usuário ao realizar login está vinculado em algum contrato. <br>\r\n4. Validar se o contrato foi cadastrado corretamente para o usuário. Caso contrário impedir o acesso ao sistema retornado a mensagem: contrato inválido. <br>\r\n5. Caso não passe por nenhuma das validações retorna que o usuário não possui contrato (Usuário sem contrato).", "2021-12-20 00:09:06", "");
INSERT INTO changelog VALUES("7", "1", "1", "1", "<ol><li>Inserido o botão/ícone no card changelog para cadastrar os registros de alteração do sistema.</li><li>Adicionada query para ordenar a exibição dos registros do changelog por ordem decrescente.<br><br></li></ol>", "2021-12-20 20:03:09", "");
DROP TABLE IF EXISTS chat_message;
CREATE TABLE `chat_message` (
  `idchat` int(11) NOT NULL AUTO_INCREMENT,
  `from_user` int(11) NOT NULL,
  `to_user` int(11) NOT NULL,
  `message` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`idchat`),
  KEY `from_user` (`from_user`),
  KEY `to_user` (`to_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
DROP TABLE IF EXISTS contrato_sistema;
CREATE TABLE `contrato_sistema` (
  `idcontratosistema` int(11) NOT NULL AUTO_INCREMENT,
  `razao_social` varchar(255) NOT NULL,
  `nome_fantasia` varchar(220) DEFAULT NULL,
  `cnpj` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `resp_financeiro` varchar(100) NOT NULL,
  `telefone` varchar(50) NOT NULL,
  `cep` varchar(9) NOT NULL,
  `rua` varchar(255) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `bairro` varchar(255) NOT NULL,
  `cidade` varchar(255) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `plano` varchar(50) NOT NULL,
  `modelo_plano` varchar(50) NOT NULL,
  `vencimento` date DEFAULT NULL,
  `valor_contrato` double NOT NULL,
  `inicio_contrato` date NOT NULL,
  `fim_contrato` date NOT NULL,
  `anexo_contrato` varchar(255) NOT NULL,
  `qtd_usuarios_liberados` int(11) DEFAULT NULL,
  `situacao_contrato_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_contrato` datetime NOT NULL,
  `modifield_contrato` datetime DEFAULT NULL,
  PRIMARY KEY (`idcontratosistema`),
  KEY `situacao_contrato_id` (`situacao_contrato_id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
DROP TABLE IF EXISTS departamento;
CREATE TABLE `departamento` (
  `id_depar` int(11) NOT NULL AUTO_INCREMENT,
  `nome_depar` varchar(255) NOT NULL,
  `descricao_depar` mediumtext NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_depar` datetime NOT NULL,
  `modificado_depar` datetime DEFAULT NULL,
  PRIMARY KEY (`id_depar`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO departamento VALUES("5", "Departamento Financeiro", "", "1", "2021-07-13 23:08:19", "");
INSERT INTO departamento VALUES("8", "Departamento de TI", "", "1", "2021-07-13 23:09:22", "");
DROP TABLE IF EXISTS email;
CREATE TABLE `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(220) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(220) NOT NULL,
  `porta` int(11) NOT NULL,
  `nome_usuario` varchar(220) DEFAULT NULL,
  `usuario_id_on` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `usuario_id_at` int(11) DEFAULT NULL,
  `modifield_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO email VALUES("1", "smtp.hostinger.com", "sistemas@companycodes.com.br", "Kab@1206", "465", "Sistema", "1", "2023-10-29 11:31:28", "1", "2023-11-04 11:59:22");
DROP TABLE IF EXISTS email_modelos;
CREATE TABLE `email_modelos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo_id` int(11) NOT NULL,
  `titulo` varchar(220) NOT NULL,
  `texto` text NOT NULL,
  `usuario_id_on` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `usuario_id_at` int(11) DEFAULT NULL,
  `modifield_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO email_modelos VALUES("2", "1", "Informações de login", "<p>Prezado&nbsp;<span style=\"font-size: 1rem;\">#login</span><span style=\"font-size: 1rem;\">,</span></p><p>Abaixo segue seus dados de acesso ao nosso sistema.</p><p>Aqui estão suas informações de login:</p><p>Nome de usuário:&nbsp;<span style=\"font-size: 1rem;\">#login</span></p><p>Senha: #senha (recomendamos a troca da senha após o primeiro login)</p><p>Lembre-se de manter suas credenciais de login seguras e não compartilhá-las com ninguém. Caso esqueça sua senha, você pode usar a opção de recuperação de senha na página de login.</p><p>Agradecemos por escolher nossa plataforma e estamos aqui para ajudá-lo em sua jornada. Desejamos a você uma ótima experiência conosco!</p><p>Atenciosamente,</p><p><span style=\"font-size: 1rem;\">#usuario_logado<br></span><span style=\"font-size: 1rem;\">#empresa</span></p>", "1", "2023-11-04 13:47:47", "1", "2023-11-05 14:40:55");
DROP TABLE IF EXISTS enquete;
CREATE TABLE `enquete` (
  `idenquete` int(11) NOT NULL AUTO_INCREMENT,
  `contrato_sistema_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `resultado` int(11) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`idenquete`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO enquete VALUES("1", "0", "1", "5", "", "2023-05-11 20:34:51");
INSERT INTO enquete VALUES("2", "1", "3", "5", "ok", "2023-05-11 20:42:51");
INSERT INTO enquete VALUES("3", "1", "4", "5", "ok2", "2023-05-11 20:44:10");
INSERT INTO enquete VALUES("4", "0", "1", "4", "", "2023-06-12 11:37:19");
INSERT INTO enquete VALUES("5", "0", "1", "5", "", "2023-10-28 10:41:09");
INSERT INTO enquete VALUES("6", "0", "1", "5", "", "2023-11-05 14:05:52");
DROP TABLE IF EXISTS enquete_rating;
CREATE TABLE `enquete_rating` (
  `idrating` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(10) NOT NULL,
  `pts` int(11) NOT NULL,
  PRIMARY KEY (`idrating`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO enquete_rating VALUES("1", "Ótimo", "5");
INSERT INTO enquete_rating VALUES("2", "Muito bom", "4");
INSERT INTO enquete_rating VALUES("3", "Bom", "3");
INSERT INTO enquete_rating VALUES("4", "Regular", "2");
INSERT INTO enquete_rating VALUES("5", "Ruim", "1");
DROP TABLE IF EXISTS evento_senha;
CREATE TABLE `evento_senha` (
  `id_eventoSenha` int(11) NOT NULL AUTO_INCREMENT,
  `nome_evento` varchar(255) NOT NULL,
  `obs_evento` mediumtext NOT NULL,
  PRIMARY KEY (`id_eventoSenha`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO evento_senha VALUES("1", "Atribuição de senha", "Quando o usuário altera sua senha.");
INSERT INTO evento_senha VALUES("2", "Troca de senha", "Quando o operador de sistemas altera a senha do usuário");
INSERT INTO evento_senha VALUES("3", "Senha via sistema/cadastro", "Quando a senha é cadastrada no ato do cadastro do usuário");
INSERT INTO evento_senha VALUES("4", "Senha expirada", "Quando a vida útil da senha chega em 40 dias ");
DROP TABLE IF EXISTS grupo;
CREATE TABLE `grupo` (
  `id_gru` int(11) NOT NULL AUTO_INCREMENT,
  `nome_gru` varchar(220) NOT NULL,
  `descricao_gru` mediumtext DEFAULT NULL,
  `grupo_pai_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_gru` datetime NOT NULL,
  `modificado_gru` datetime DEFAULT NULL,
  PRIMARY KEY (`id_gru`),
  KEY `usuario_id` (`usuario_id`),
  KEY `grupo_pai_id` (`grupo_pai_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO grupo VALUES("1", "Raiz", "Grupo padrão do sistema", "1", "1", "2020-09-23 00:00:00", "");
DROP TABLE IF EXISTS hist_senha;
CREATE TABLE `hist_senha` (
  `id_histSenha` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `operador` int(11) NOT NULL,
  `evento_senha_id` int(11) NOT NULL,
  `created_hist_senha` datetime NOT NULL,
  PRIMARY KEY (`id_histSenha`),
  KEY `operador` (`operador`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO hist_senha VALUES("1", "3", "1", "3", "2023-05-11 20:33:37");
INSERT INTO hist_senha VALUES("2", "3", "3", "1", "2023-05-11 20:38:30");
INSERT INTO hist_senha VALUES("3", "4", "3", "3", "2023-05-11 20:42:34");
INSERT INTO hist_senha VALUES("4", "4", "4", "1", "2023-05-11 20:43:19");
INSERT INTO hist_senha VALUES("5", "1", "3", "2", "2023-05-12 02:27:45");
INSERT INTO hist_senha VALUES("6", "1", "1", "1", "2023-05-12 02:28:27");
INSERT INTO hist_senha VALUES("7", "1", "2", "4", "2023-06-12 10:25:06");
INSERT INTO hist_senha VALUES("8", "1", "1", "1", "2023-06-12 10:38:06");
INSERT INTO hist_senha VALUES("9", "1", "2", "4", "2023-10-28 10:12:23");
INSERT INTO hist_senha VALUES("10", "1", "2", "4", "2023-10-28 10:41:09");
INSERT INTO hist_senha VALUES("11", "1", "1", "1", "2023-10-28 11:10:39");
INSERT INTO hist_senha VALUES("12", "2", "1", "3", "2023-11-05 13:51:17");
INSERT INTO hist_senha VALUES("13", "3", "1", "3", "2023-11-05 14:00:50");
INSERT INTO hist_senha VALUES("14", "4", "1", "3", "2023-11-05 14:03:54");
INSERT INTO hist_senha VALUES("15", "5", "1", "3", "2023-11-05 14:06:47");
INSERT INTO hist_senha VALUES("16", "6", "1", "3", "2023-11-05 14:11:27");
INSERT INTO hist_senha VALUES("17", "7", "1", "3", "2023-11-05 14:41:55");
INSERT INTO hist_senha VALUES("18", "8", "1", "3", "2023-11-05 14:43:25");
DROP TABLE IF EXISTS modelos_plano;
CREATE TABLE `modelos_plano` (
  `idmodeloplano` int(11) NOT NULL AUTO_INCREMENT,
  `nome_mod_plano` varchar(200) NOT NULL,
  `valor_plano` double NOT NULL,
  `plano_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_modelo_plano` datetime NOT NULL,
  `modifield_modelo_plano` datetime DEFAULT NULL,
  PRIMARY KEY (`idmodeloplano`),
  KEY `plano_id` (`plano_id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO modelos_plano VALUES("1", "Premium", "2750", "1", "1", "2021-12-15 00:01:09", "");
INSERT INTO modelos_plano VALUES("2", "Premium", "250", "2", "1", "2021-12-15 00:01:57", "");
DROP TABLE IF EXISTS modulos;
CREATE TABLE `modulos` (
  `id_mod` int(11) NOT NULL AUTO_INCREMENT,
  `nome_mod` varchar(200) NOT NULL,
  `chave_mod` varchar(200) NOT NULL,
  `descricao_mod` mediumtext NOT NULL,
  `permissao_mod` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `created_mod` datetime NOT NULL,
  `modifield_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id_mod`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO modulos VALUES("1", "Controle de acesso", "pages/modulo/controle_de_acesso", "Configurações gerais do sistema", "1", "1", "2020-11-17 00:00:00", "");
INSERT INTO modulos VALUES("2", "Página inicial", "pages/modulo/home", "Página inicial do sistema", "1", "1", "2020-11-17 00:00:00", "2023-06-12 11:36:39");
INSERT INTO modulos VALUES("6", "Meu perfil", "pages/modulo/perfil", "Perfil do usuário", "1", "1", "2021-03-25 00:00:00", "2021-12-08 16:47:13");
INSERT INTO modulos VALUES("8", "Importação", "pages/modulo/importar", "Importação e exportação de dados", "1", "1", "2021-05-03 00:00:00", "2023-06-12 11:36:19");
INSERT INTO modulos VALUES("12", "Sistema", "pages/modulo/sistema", "Modulo de administração do sistema", "1", "1", "2021-05-22 00:00:00", "2021-12-08 16:46:20");
INSERT INTO modulos VALUES("13", "Cadastro", "pages/modulo/Cadastro", "Cadastro", "1", "1", "2023-04-26 19:05:38", "");
INSERT INTO modulos VALUES("15", "logout", "pages/modulo/logout", "Sair do sistema", "1", "1", "2023-06-12 11:34:24", "");
INSERT INTO modulos VALUES("16", "e-mail", "pages/modulo/email", "Servidor de e-mail", "1", "1", "2023-10-29 10:57:24", "");
DROP TABLE IF EXISTS niveis_acessos;
CREATE TABLE `niveis_acessos` (
  `id_nvl` int(11) NOT NULL AUTO_INCREMENT,
  `nome_nvl` varchar(100) NOT NULL,
  `ordem_nvl` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_nvl` datetime NOT NULL,
  `modificado_nvl` datetime DEFAULT NULL,
  PRIMARY KEY (`id_nvl`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO niveis_acessos VALUES("1", "Master", "1", "1", "2020-09-16 00:00:00", "2020-10-02 17:40:20");
DROP TABLE IF EXISTS niveis_acessos_paginas;
CREATE TABLE `niveis_acessos_paginas` (
  `id_nvl_pg` int(11) NOT NULL AUTO_INCREMENT,
  `niveis_acesso_id` int(11) NOT NULL,
  `pagina_id` int(11) NOT NULL,
  `permissao` int(11) NOT NULL,
  `menu` int(11) NOT NULL DEFAULT 2,
  `ordem` int(11) NOT NULL,
  `criado_nvl_pg` datetime NOT NULL,
  `modificado_nvl_pg` datetime DEFAULT NULL,
  PRIMARY KEY (`id_nvl_pg`),
  KEY `niveis_acesso_id` (`niveis_acesso_id`),
  KEY `menu` (`menu`),
  KEY `permissao` (`permissao`),
  KEY `pagina_id` (`pagina_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1028 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO niveis_acessos_paginas VALUES("5", "1", "8", "1", "1", "2", "2020-09-17 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("6", "1", "7", "1", "1", "1", "2020-09-17 00:00:00", "2023-05-12 02:29:32");
INSERT INTO niveis_acessos_paginas VALUES("12", "1", "11", "1", "2", "1", "2020-09-21 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("13", "1", "12", "1", "2", "1", "2020-09-23 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("14", "1", "13", "1", "2", "1", "2020-09-23 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("15", "1", "14", "1", "2", "1", "2020-09-23 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("16", "1", "15", "1", "2", "1", "2020-09-23 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("17", "1", "16", "1", "2", "1", "2020-09-23 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("18", "1", "17", "1", "2", "1", "2020-09-24 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("19", "1", "18", "1", "2", "18", "2020-09-25 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("25", "1", "19", "1", "2", "19", "2020-09-27 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("26", "1", "20", "1", "2", "20", "2020-09-27 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("27", "1", "21", "1", "2", "21", "2020-10-01 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("28", "1", "22", "1", "2", "22", "2020-10-01 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("29", "1", "23", "1", "2", "23", "2020-10-01 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("30", "1", "24", "1", "2", "24", "2020-10-01 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("34", "1", "25", "1", "2", "25", "2020-10-02 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("35", "1", "26", "1", "2", "26", "2020-10-02 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("36", "1", "27", "1", "2", "27", "2020-10-02 00:00:00", "2023-05-12 02:31:33");
INSERT INTO niveis_acessos_paginas VALUES("37", "1", "28", "1", "2", "28", "2020-11-03 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("46", "1", "29", "1", "2", "29", "2020-11-17 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("73", "1", "2", "1", "2", "31", "2020-11-18 12:59:20", "2023-05-12 02:30:21");
INSERT INTO niveis_acessos_paginas VALUES("74", "1", "3", "1", "2", "31", "2020-11-18 12:59:20", "2023-05-12 02:29:55");
INSERT INTO niveis_acessos_paginas VALUES("75", "1", "4", "1", "2", "31", "2020-11-18 12:59:20", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("76", "1", "5", "1", "2", "31", "2020-11-18 12:59:20", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("77", "1", "9", "1", "2", "31", "2020-11-18 12:59:20", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("78", "1", "10", "1", "2", "31", "2020-11-18 12:59:20", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("404", "1", "30", "1", "2", "60", "2020-11-19 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("405", "1", "31", "1", "2", "61", "2020-11-19 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("406", "1", "32", "1", "2", "62", "2020-11-19 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("407", "1", "33", "1", "2", "63", "2020-11-21 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("408", "1", "34", "1", "2", "64", "2020-11-21 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("409", "1", "35", "1", "2", "65", "2020-11-21 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("410", "1", "36", "1", "2", "66", "2020-11-21 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("411", "1", "37", "1", "2", "67", "2020-11-23 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("412", "1", "38", "1", "2", "68", "2020-11-24 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("413", "1", "39", "1", "2", "69", "2020-11-24 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("414", "1", "40", "1", "2", "70", "2020-11-24 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("415", "1", "41", "1", "2", "71", "2020-11-24 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("451", "1", "77", "1", "2", "107", "2021-02-11 00:00:00", "2023-05-12 02:31:03");
INSERT INTO niveis_acessos_paginas VALUES("663", "1", "93", "1", "1", "213", "2021-03-25 00:00:00", "2021-12-11 15:30:45");
INSERT INTO niveis_acessos_paginas VALUES("664", "1", "94", "1", "2", "214", "2021-03-26 00:00:00", "2021-12-11 12:21:11");
INSERT INTO niveis_acessos_paginas VALUES("665", "1", "95", "1", "2", "215", "2021-03-26 00:00:00", "2021-12-10 17:12:53");
INSERT INTO niveis_acessos_paginas VALUES("669", "1", "99", "1", "1", "219", "2021-05-03 00:00:00", "2023-05-12 02:32:01");
INSERT INTO niveis_acessos_paginas VALUES("670", "1", "100", "1", "2", "220", "2021-05-03 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("679", "1", "109", "1", "1", "226", "2021-05-22 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("686", "1", "116", "1", "2", "232", "2021-07-10 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("687", "1", "117", "1", "2", "233", "2021-07-10 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("688", "1", "118", "1", "2", "234", "2021-07-10 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("689", "1", "119", "1", "2", "235", "2021-07-10 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("690", "1", "120", "1", "2", "236", "2021-07-10 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("691", "1", "121", "1", "2", "237", "2021-07-10 00:00:00", "2021-12-10 17:26:45");
INSERT INTO niveis_acessos_paginas VALUES("836", "1", "129", "1", "2", "238", "2021-12-11 14:51:11", "");
INSERT INTO niveis_acessos_paginas VALUES("890", "1", "130", "1", "2", "239", "2021-12-11 21:49:34", "");
INSERT INTO niveis_acessos_paginas VALUES("891", "1", "131", "1", "2", "240", "2021-12-13 23:00:13", "");
INSERT INTO niveis_acessos_paginas VALUES("892", "1", "132", "1", "2", "241", "2021-12-14 23:05:56", "");
INSERT INTO niveis_acessos_paginas VALUES("893", "1", "133", "1", "2", "242", "2021-12-14 23:35:41", "");
INSERT INTO niveis_acessos_paginas VALUES("894", "1", "134", "1", "2", "243", "2021-12-16 09:57:37", "2021-12-16 09:58:17");
INSERT INTO niveis_acessos_paginas VALUES("978", "1", "135", "1", "2", "244", "2021-12-17 21:43:15", "2021-12-17 21:45:20");
INSERT INTO niveis_acessos_paginas VALUES("981", "1", "136", "1", "2", "245", "2021-12-19 14:09:52", "2021-12-19 14:12:16");
INSERT INTO niveis_acessos_paginas VALUES("984", "1", "137", "1", "2", "246", "2021-12-19 19:03:33", "");
INSERT INTO niveis_acessos_paginas VALUES("987", "1", "138", "1", "2", "247", "2021-12-20 19:25:25", "");
INSERT INTO niveis_acessos_paginas VALUES("990", "1", "139", "1", "2", "248", "2021-12-20 20:38:11", "2021-12-20 20:38:30");
INSERT INTO niveis_acessos_paginas VALUES("995", "1", "140", "1", "2", "249", "2021-12-31 16:14:36", "");
INSERT INTO niveis_acessos_paginas VALUES("1007", "2", "7", "1", "1", "1", "2023-05-11 20:39:54", "2023-05-12 02:29:32");
INSERT INTO niveis_acessos_paginas VALUES("1008", "2", "93", "1", "1", "2", "2023-05-11 20:39:54", "");
INSERT INTO niveis_acessos_paginas VALUES("1009", "2", "94", "1", "2", "3", "2023-05-11 20:39:54", "2023-05-11 20:40:07");
INSERT INTO niveis_acessos_paginas VALUES("1010", "2", "95", "1", "2", "4", "2023-05-11 20:39:54", "2023-05-11 20:40:07");
INSERT INTO niveis_acessos_paginas VALUES("1022", "1", "153", "1", "2", "250", "2023-06-12 11:35:48", "");
INSERT INTO niveis_acessos_paginas VALUES("1023", "1", "154", "1", "1", "251", "2023-10-29 10:59:14", "");
INSERT INTO niveis_acessos_paginas VALUES("1024", "1", "155", "1", "2", "252", "2023-10-29 11:29:07", "");
INSERT INTO niveis_acessos_paginas VALUES("1025", "1", "156", "1", "2", "253", "2023-11-04 11:24:49", "");
INSERT INTO niveis_acessos_paginas VALUES("1026", "1", "157", "1", "2", "254", "2023-11-05 14:35:38", "");
INSERT INTO niveis_acessos_paginas VALUES("1027", "1", "158", "1", "2", "255", "2023-11-05 14:51:23", "");
DROP TABLE IF EXISTS objeto_paginas;
CREATE TABLE `objeto_paginas` (
  `idobj` int(11) NOT NULL AUTO_INCREMENT,
  `objeto` varchar(50) NOT NULL,
  PRIMARY KEY (`idobj`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO objeto_paginas VALUES("1", "Tela");
INSERT INTO objeto_paginas VALUES("2", "Botão");
INSERT INTO objeto_paginas VALUES("3", "Submenu");
DROP TABLE IF EXISTS opcoes_menu;
CREATE TABLE `opcoes_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO opcoes_menu VALUES("1", "Ativo");
INSERT INTO opcoes_menu VALUES("2", "Inativo");
DROP TABLE IF EXISTS paginas;
CREATE TABLE `paginas` (
  `id_pg` int(11) NOT NULL AUTO_INCREMENT,
  `icon` longtext DEFAULT NULL,
  `endereco_pg` varchar(520) NOT NULL,
  `nome_pg` varchar(220) NOT NULL,
  `menu_lateral` int(11) NOT NULL DEFAULT 2 COMMENT 'se o valor for 1: aparecer no menu lateral. Se o valor for 2: não aparecer',
  `objeto_id` int(11) DEFAULT NULL,
  `modulo_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ordem_menu` int(11) DEFAULT NULL,
  `criado_pg` datetime NOT NULL,
  `modificado_pg` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pg`),
  KEY `modulo_id` (`modulo_id`),
  KEY `objeto_id` (`objeto_id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO paginas VALUES("2", "", "pages/modulo/controle_de_acesso/cadastrar/cad_usuario", "Cadastrar Usuário", "2", "1", "1", "1", "", "2020-09-16 00:00:00", "2023-05-12 02:30:21");
INSERT INTO paginas VALUES("3", "", "pages/modulo/controle_de_acesso/editar/edit_usuario", "Editar Usuário", "2", "1", "1", "1", "", "2020-09-16 00:00:00", "2023-05-12 02:29:55");
INSERT INTO paginas VALUES("4", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_usuario", "proc_cad_usuario", "2", "2", "1", "1", "", "2020-09-16 00:00:00", "2021-12-08 23:14:56");
INSERT INTO paginas VALUES("5", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_usuario", "proc_edit_usuario", "2", "2", "1", "1", "", "2020-09-16 00:00:00", "2021-05-21 10:29:43");
INSERT INTO paginas VALUES("7", "fa fa-home", "pages/modulo/home/home", "Página inicial", "1", "1", "2", "1", "1", "2020-09-16 00:00:00", "2023-05-12 02:29:32");
INSERT INTO paginas VALUES("8", "fa fa-lock", "pages/modulo/controle_de_acesso/controle_de_acesso", "Controle de Acesso", "1", "1", "1", "1", "2", "2020-09-17 00:00:00", "2021-05-21 10:30:01");
INSERT INTO paginas VALUES("9", "", "pages/modulo/controle_de_acesso/apagar/proc_del_usuario", "proc_del_usuario", "2", "2", "1", "1", "", "2020-09-18 00:00:00", "2021-12-08 16:33:10");
INSERT INTO paginas VALUES("10", "", "pages/modulo/controle_de_acesso/cadastrar/cad_unidade", "Cadastrar Unidade", "2", "1", "1", "1", "", "2020-09-21 00:00:00", "2021-05-21 10:30:29");
INSERT INTO paginas VALUES("11", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_unidade", "proc_cad_unidade", "2", "2", "1", "1", "", "2020-09-23 00:00:00", "2021-05-21 10:30:40");
INSERT INTO paginas VALUES("12", "", "pages/modulo/controle_de_acesso/cadastrar/cad_grupo", "Cadastrar Grupo", "2", "1", "1", "1", "", "2020-09-23 00:00:00", "2021-05-21 10:30:52");
INSERT INTO paginas VALUES("13", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_grupo", "proc_cad_grupo", "2", "2", "1", "1", "", "2020-09-23 00:44:00", "2021-05-21 10:31:05");
INSERT INTO paginas VALUES("14", "", "pages/modulo/controle_de_acesso/cadastrar/cad_cargo", "Cadastrar Cargo", "2", "1", "1", "1", "", "2020-09-23 00:00:00", "2021-05-21 10:31:17");
INSERT INTO paginas VALUES("15", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_cargo", "proc_cad_cargo", "2", "2", "1", "1", "", "2020-09-23 00:00:00", "2021-05-21 10:31:33");
INSERT INTO paginas VALUES("16", "", "pages/modulo/controle_de_acesso/cadastrar/cad_permissao", "Cadastrar Perfil de Acesso", "2", "1", "1", "1", "", "2020-09-23 00:00:00", "2021-05-21 10:46:00");
INSERT INTO paginas VALUES("17", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_permissao", "proc_cad_permissao", "2", "2", "1", "1", "", "2020-09-24 00:00:00", "2021-05-21 10:46:11");
INSERT INTO paginas VALUES("18", "", "pages/modulo/controle_de_acesso/listar/list_permissao", "Permissões do Perfil de Acesso", "2", "1", "1", "1", "", "2020-09-25 00:00:00", "2021-07-09 21:40:02");
INSERT INTO paginas VALUES("19", "", "pages/modulo/controle_de_acesso/editar/edit_cargo", "Editar Cargo", "2", "1", "1", "1", "", "2020-09-27 00:00:00", "2021-05-21 10:46:34");
INSERT INTO paginas VALUES("20", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_cargo", "proc_edit_cargo", "2", "2", "1", "1", "", "2020-09-27 00:00:00", "2021-12-08 16:32:39");
INSERT INTO paginas VALUES("21", "", "pages/modulo/controle_de_acesso/editar/edit_grupo", "Editar Grupo", "2", "1", "1", "1", "", "2020-10-01 00:00:00", "2021-05-21 10:46:56");
INSERT INTO paginas VALUES("22", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_grupo", "proc_edit_grupo", "2", "2", "1", "1", "", "2020-10-01 00:00:00", "2021-05-21 10:47:08");
INSERT INTO paginas VALUES("23", "", "pages/modulo/controle_de_acesso/editar/edit_unidade", "Editar unidade", "2", "1", "1", "1", "", "2020-10-01 00:00:00", "2021-05-21 10:47:18");
INSERT INTO paginas VALUES("24", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_unidade", "proc_edit_unidade", "2", "2", "1", "1", "", "2020-10-01 00:00:00", "2021-05-21 10:47:28");
INSERT INTO paginas VALUES("25", "", "pages/modulo/controle_de_acesso/editar/edit_perfil", "Editar perfil", "2", "1", "1", "1", "", "2020-10-02 00:00:00", "2021-05-21 10:47:39");
INSERT INTO paginas VALUES("26", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_perfil", "proc_edit_perfil", "2", "2", "1", "1", "", "2020-10-02 00:00:00", "2021-05-21 10:47:50");
INSERT INTO paginas VALUES("27", "fa fa-code", "pages/modulo/sistema/editar/edit_fluxo", "Editar operação", "2", "1", "12", "1", "", "2020-10-02 00:00:00", "2023-05-12 02:31:33");
INSERT INTO paginas VALUES("28", "fa fa-code", "pages/modulo/sistema/editar/processa/proc_edit_fluxo", "Processa fluxo", "2", "2", "1", "1", "", "2020-11-03 00:00:00", "2021-05-21 10:48:11");
INSERT INTO paginas VALUES("29", "", "pages/modulo/controle_de_acesso/editar/processa/proc_autoriza_desautoriza_permissao", "processa autoriza e desautoriza permissões ", "2", "2", "1", "1", "", "2020-11-17 00:00:00", "2021-07-09 21:28:12");
INSERT INTO paginas VALUES("30", "", "pages/modulo/controle_de_acesso/editar/edit_senha_usuario", "Redefinir senha", "2", "1", "1", "1", "", "2020-11-19 00:00:00", "2021-05-21 10:48:58");
INSERT INTO paginas VALUES("31", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_senha_usuario", "processa edita senha do usuário", "2", "2", "1", "1", "", "2020-11-19 00:00:00", "2021-07-09 21:28:57");
INSERT INTO paginas VALUES("32", "", "pages/modulo/controle_de_acesso/listar/list_hist_atualizacao", "Histórico de atualização", "2", "1", "1", "1", "", "2020-11-19 00:00:00", "2021-07-09 21:40:40");
INSERT INTO paginas VALUES("33", "", "pages/modulo/controle_de_acesso/cadastrar/cad_departamento", "Cadastrar departamento", "2", "1", "1", "1", "", "2020-11-21 00:00:00", "2021-05-21 10:53:15");
INSERT INTO paginas VALUES("34", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_departamento", "proc_cad_departamento", "2", "2", "1", "1", "", "2020-11-21 00:00:00", "2021-05-21 10:53:37");
INSERT INTO paginas VALUES("35", "", "pages/modulo/controle_de_acesso/editar/edit_departamento", "Editar departamento", "2", "1", "1", "1", "", "2020-11-21 00:00:00", "2021-05-21 10:54:02");
INSERT INTO paginas VALUES("36", "", "pages/modulo/controle_de_acesso/editar/processa/proc_edit_departamento", "proc_edit_departamento", "2", "2", "1", "1", "", "2020-11-21 00:00:00", "2021-05-21 10:54:32");
INSERT INTO paginas VALUES("37", "", "pages/modulo/controle_de_acesso/apagar/proc_del_cargo", "Processa deletar cargo", "2", "2", "1", "1", "", "2020-11-23 00:00:00", "2021-05-21 10:54:44");
INSERT INTO paginas VALUES("38", "", "pages/modulo/controle_de_acesso/apagar/proc_del_departamento", "Processa deleta departamento", "2", "2", "1", "1", "", "2020-11-24 00:00:00", "2021-05-21 10:55:22");
INSERT INTO paginas VALUES("39", "", "pages/modulo/controle_de_acesso/apagar/proc_del_grupo", "processa deleta grupos", "2", "2", "1", "1", "", "2020-11-24 00:00:00", "2021-05-21 10:55:52");
INSERT INTO paginas VALUES("40", "", "pages/modulo/controle_de_acesso/apagar/proc_del_unidade", "processa delete unidade", "2", "2", "1", "1", "", "2020-11-24 00:00:00", "2021-05-21 10:56:04");
INSERT INTO paginas VALUES("41", "", "pages/modulo/controle_de_acesso/apagar/proc_del_perfil", "processa deleta perfil", "2", "2", "1", "1", "", "2020-11-24 00:00:00", "2021-05-21 10:56:17");
INSERT INTO paginas VALUES("77", "", "pages/modulo/controle_de_acesso/listar/list_operacoes", "Operações do sistema", "2", "3", "1", "1", "", "2021-02-11 00:00:00", "2023-05-12 02:31:03");
INSERT INTO paginas VALUES("93", "fa fa-user", "pages/modulo/meu_perfil/perfil", "Meu perfil", "1", "1", "6", "1", "3", "2021-03-25 00:00:00", "2021-12-11 15:30:45");
INSERT INTO paginas VALUES("94", "fa fa-user", "pages/modulo/meu_perfil/processa/proc_altera_senha", "btn_proc_altera_senha", "2", "2", "6", "1", "", "2021-03-26 00:00:00", "2021-05-21 11:09:22");
INSERT INTO paginas VALUES("95", "fa fa-user", "pages/modulo/meu_perfil/processa/proc_altera_usuario", "btn_proc_altera_usuario", "2", "2", "6", "1", "", "2021-03-26 00:00:00", "2021-05-21 11:09:33");
INSERT INTO paginas VALUES("99", "fa fa-database", "pages/modulo/importar/importar", "Importação", "1", "1", "8", "1", "4", "2021-05-03 00:00:00", "2023-05-12 02:32:01");
INSERT INTO paginas VALUES("100", "fa fa-database", "pages/modulo/importar/processa/proc_cad_cliente", "proc_cad_cliente", "2", "2", "8", "1", "", "2021-05-03 00:00:00", "2021-05-21 10:58:06");
INSERT INTO paginas VALUES("109", "fa fa-code", "pages/modulo/sistema/sistema", "Sistema", "1", "1", "12", "1", "5", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("116", "fa fa-code", "pages/modulo/sistema/cadastrar/processa/proc_cad_modulo", "proc_cad_modulo", "2", "2", "12", "1", "", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("117", "fa fa-code", "pages/modulo/sistema/editar/edit_modulo", "Editar modulo", "2", "1", "12", "1", "", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("118", "fa fa-code", "pages/modulo/sistema/editar/processa/proc_edit_modulo", "proc_edit_modulo", "2", "2", "12", "1", "", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("119", "fa fa-code", "pages/modulo/sistema/apagar/processa/proc_del_modulo", "proc_del_modulo", "2", "2", "12", "1", "", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("120", "fa fa-code", "pages/modulo/sistema/apagar/processa/proc_del_fluxo", "proc_del_fluxo", "2", "2", "12", "1", "", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("121", "fa fa-code", "pages/modulo/sistema/cadastrar/processa/proc_cad_fluxo", "proc_cad_fluxo", "2", "2", "12", "1", "", "2021-05-22 00:00:00", "");
INSERT INTO paginas VALUES("129", "", "pages/modulo/controle_de_acesso/cadastrar/processa/proc_cad_nova_permissao", "btn_proc_cad_nova_permissao", "2", "2", "1", "1", "", "2021-12-11 14:51:11", "");
INSERT INTO paginas VALUES("130", "", "pages/modulo/sistema/cadastrar/processa/proc_cad_personalizacao", "btn_proc_cad_personalizacao", "2", "2", "12", "1", "", "2021-12-11 21:49:34", "");
INSERT INTO paginas VALUES("131", "", "pages/modulo/sistema/cadastrar/processa/proc_cad_contrato", "btn_proc_cad_contrato", "2", "2", "12", "1", "", "2021-12-13 23:00:13", "");
INSERT INTO paginas VALUES("132", "", "pages/modulo/sistema/cadastrar/processa/proc_cad_plano", "btn_proc_cad_plano", "2", "2", "12", "1", "", "2021-12-14 23:05:56", "");
INSERT INTO paginas VALUES("133", "", "pages/modulo/sistema/cadastrar/processa/proc_cad_preco", "btn_proc_cad_preco", "2", "2", "12", "1", "", "2021-12-14 23:35:41", "");
INSERT INTO paginas VALUES("134", "", "pages/modulo/sistema/cadastrar/cad_contrato", "Cadastrar contrato", "2", "1", "12", "1", "", "2021-12-16 09:57:37", "2021-12-16 09:58:17");
INSERT INTO paginas VALUES("135", "", "pages/modulo/sistema/editar/edit_contrato", "Editar contrato", "2", "1", "12", "1", "", "2021-12-17 21:43:15", "2021-12-17 21:45:20");
INSERT INTO paginas VALUES("136", "", "pages/modulo/sistema/editar/processa/proc_edit_contrato", "btn_proc_edit_contrato", "2", "2", "12", "1", "", "2021-12-19 14:09:52", "2021-12-19 14:12:16");
INSERT INTO paginas VALUES("137", "", "pages/modulo/sistema/editar/processa/proc_edit_anexo", "btn_proc_edit_anexo", "2", "2", "12", "1", "", "2021-12-19 19:03:33", "");
INSERT INTO paginas VALUES("138", "", "pages/modulo/sistema/cadastrar/processa/proc_cad_changelog", "btn_proc_cad_changelog", "2", "2", "12", "1", "", "2021-12-20 19:25:25", "");
INSERT INTO paginas VALUES("139", "", "pages/modulo/sistema/cadastrar/processa/proc_cad_versao", "btn_proc_cad_versao", "2", "2", "12", "1", "", "2021-12-20 20:38:11", "2021-12-20 20:38:30");
INSERT INTO paginas VALUES("140", "", "pages/modulo/importar/processa/proc_import_usuario", "btn_proc_import_usuario", "2", "2", "8", "1", "", "2021-12-31 16:14:36", "");
INSERT INTO paginas VALUES("153", "", "pages/modulo/logout/sair", "sair", "2", "2", "15", "1", "1", "2023-06-12 11:35:48", "");
INSERT INTO paginas VALUES("154", "fa fa-envelope", "pages/modulo/e-mail/e-mail", "E-mail", "1", "1", "16", "1", "2", "2023-10-29 10:59:14", "");
INSERT INTO paginas VALUES("155", "", "pages/modulo/e-mail/cadastrar/processa/proc_cad_servidor", "proc_cad_servidor", "2", "2", "16", "1", "1", "2023-10-29 11:29:07", "");
INSERT INTO paginas VALUES("156", "", "pages/modulo/e-mail/cadastrar/processa/proc_cad_modelo", "proc_cad_modelo", "2", "2", "16", "1", "1", "2023-11-04 11:24:49", "");
INSERT INTO paginas VALUES("157", "", "pages/modulo/e-mail/editar/processa/proc_edit_modelo", "proc_edit_modelo", "2", "2", "16", "1", "1", "2023-11-05 14:35:38", "");
INSERT INTO paginas VALUES("158", "", "pages/modulo/e-mail/apagar/proc_del_modelo", "proc_del_modelo", "2", "2", "16", "1", "1", "2023-11-05 14:51:23", "");
DROP TABLE IF EXISTS personalizacao_sistema;
CREATE TABLE `personalizacao_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_sistema` varchar(200) NOT NULL,
  `site_sistema` varchar(200) NOT NULL,
  `nome_empresa` varchar(255) NOT NULL,
  `versao_atual_sistema` int(11) NOT NULL,
  `logo_sistema` varchar(255) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado` datetime NOT NULL,
  `modificado` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO personalizacao_sistema VALUES("1", "Site", "https://www.companycodes.com.br", "Company Codes", "1", "168634705764839d3143a76.png", "1", "2021-12-12 19:53:34", "2023-06-09 16:44:17");
DROP TABLE IF EXISTS planos;
CREATE TABLE `planos` (
  `idplano` int(11) NOT NULL AUTO_INCREMENT,
  `nome_plano` varchar(200) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_plano` datetime NOT NULL,
  `modifield_plano` datetime DEFAULT NULL,
  PRIMARY KEY (`idplano`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO planos VALUES("1", "Anual", "1", "2021-12-17 13:05:49", "");
INSERT INTO planos VALUES("2", "Mensal", "1", "2021-12-17 13:06:07", "");
DROP TABLE IF EXISTS situacao_contrato;
CREATE TABLE `situacao_contrato` (
  `idsituacaocontrato` int(11) NOT NULL AUTO_INCREMENT,
  `status_contrato` varchar(100) NOT NULL,
  PRIMARY KEY (`idsituacaocontrato`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO situacao_contrato VALUES("1", "Ativo");
INSERT INTO situacao_contrato VALUES("2", "Inativo");
INSERT INTO situacao_contrato VALUES("3", "Cancelado");
DROP TABLE IF EXISTS situacoes_menu;
CREATE TABLE `situacoes_menu` (
  `id_st_me` int(11) NOT NULL AUTO_INCREMENT,
  `nome_st_me` varchar(100) NOT NULL,
  `cor_st_me` varchar(100) NOT NULL,
  `criado_st_me` datetime NOT NULL,
  PRIMARY KEY (`id_st_me`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO situacoes_menu VALUES("1", "Ativo", "text-success", "2020-09-25 00:00:00");
INSERT INTO situacoes_menu VALUES("2", "Inativo", "text-danger", "2020-09-25 00:00:00");
DROP TABLE IF EXISTS situacoes_permisoes;
CREATE TABLE `situacoes_permisoes` (
  `id_st_perm` int(11) NOT NULL AUTO_INCREMENT,
  `nome_st_perm` varchar(100) NOT NULL,
  `cor_st_perm` varchar(100) NOT NULL,
  `criado_st_perm` datetime NOT NULL,
  PRIMARY KEY (`id_st_perm`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO situacoes_permisoes VALUES("1", "Ativo", "text-success", "2020-09-25 00:00:00");
INSERT INTO situacoes_permisoes VALUES("2", "Inativo", "text-danger", "2020-09-25 00:00:00");
DROP TABLE IF EXISTS situacoes_usuarios;
CREATE TABLE `situacoes_usuarios` (
  `id_situacao` int(11) NOT NULL AUTO_INCREMENT,
  `nome_situacao` varchar(50) NOT NULL,
  `cor_situacao` varchar(50) NOT NULL,
  `criado_situacao` datetime NOT NULL,
  `modificado_situacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_situacao`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO situacoes_usuarios VALUES("1", "Ativo", "text-success", "2020-09-16 00:00:00", "");
INSERT INTO situacoes_usuarios VALUES("2", "Inativo", "text-danger", "2020-09-18 00:00:00", "");
INSERT INTO situacoes_usuarios VALUES("3", "Senha resetada", "text-danger", "2020-11-23 00:00:00", "");
INSERT INTO situacoes_usuarios VALUES("4", "Senha expirada", "text-danger", "2020-11-23 00:00:00", "");
INSERT INTO situacoes_usuarios VALUES("5", "Conta e senha ativa", "text-success", "2020-11-23 00:00:00", "");
DROP TABLE IF EXISTS unidade;
CREATE TABLE `unidade` (
  `id_uni` int(11) NOT NULL AUTO_INCREMENT,
  `nome_uni` varchar(250) NOT NULL,
  `sigla_uni` varchar(7) NOT NULL,
  `descricao_uni` mediumtext DEFAULT NULL,
  `grupo_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `criado_uni` datetime NOT NULL,
  `modificado_uni` datetime DEFAULT NULL,
  PRIMARY KEY (`id_uni`),
  KEY `grupo_id` (`grupo_id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO unidade VALUES("1", "Unidade padrão", "UP", "Unidade do sistema", "1", "1", "2020-09-21 00:00:00", "2023-05-12 02:42:07");
DROP TABLE IF EXISTS usuarios;
CREATE TABLE `usuarios` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nome_user` varchar(220) NOT NULL,
  `email_user` varchar(220) NOT NULL,
  `login_user` varchar(220) NOT NULL,
  `senha_user` varchar(220) NOT NULL,
  `token` mediumtext DEFAULT NULL,
  `niveis_acesso_id` int(11) NOT NULL,
  `situacoes_usuario_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  `unidade_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `contrato_sistema_id` int(11) DEFAULT NULL,
  `anotacao` mediumtext DEFAULT NULL,
  `foto` varchar(200) DEFAULT NULL,
  `criado_user` datetime NOT NULL,
  `modificado_user` datetime DEFAULT NULL,
  `ult_token` datetime DEFAULT NULL,
  `ult_acesso` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `contrato_sistema_id` (`contrato_sistema_id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `niveis_acesso_id` (`niveis_acesso_id`),
  KEY `situacoes_usuario_id` (`situacoes_usuario_id`),
  KEY `unidade_id` (`unidade_id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO usuarios VALUES("1", "KALLEB ALVES BARBOSA", "kallebalves1@gmail.com", "kalleb.barbosa", "$2y$10$P6Qgz1h5DcHt2Z/fY2o.beUJIYKhNIYDq93OFCKQZIE/uyguxygmO", "0F19AF42FFF865440FD332BF6782F4ABAEC094E443F471916FBEAA611CF5C7BA", "1", "5", "1", "1", "1", "", "Usuário máster do sistema", "", "2021-12-17 18:42:31", "2023-10-28 11:10:39", "2023-11-06 16:25:13", "2023-11-05 14:05:52");
DROP TABLE IF EXISTS usuarios_contrato;
CREATE TABLE `usuarios_contrato` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `situacao` varchar(50) NOT NULL,
  `qtd` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO usuarios_contrato VALUES("1", "1", "1");
INSERT INTO usuarios_contrato VALUES("2", "5", "5");
INSERT INTO usuarios_contrato VALUES("3", "10", "10");
INSERT INTO usuarios_contrato VALUES("4", "15", "15");
INSERT INTO usuarios_contrato VALUES("5", "20", "20");
INSERT INTO usuarios_contrato VALUES("6", "25", "25");
INSERT INTO usuarios_contrato VALUES("7", "30", "30");
INSERT INTO usuarios_contrato VALUES("8", "35", "35");
INSERT INTO usuarios_contrato VALUES("9", "40", "40");
INSERT INTO usuarios_contrato VALUES("10", "45", "45");
INSERT INTO usuarios_contrato VALUES("11", "50", "50");
INSERT INTO usuarios_contrato VALUES("12", "Ilimitado", "999999");
DROP TABLE IF EXISTS versoes;
CREATE TABLE `versoes` (
  `idversao` int(11) NOT NULL AUTO_INCREMENT,
  `versao` varchar(255) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `created_versao` datetime NOT NULL,
  `modifield_versao` datetime DEFAULT NULL,
  PRIMARY KEY (`idversao`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO versoes VALUES("1", "0.0.1", "1", "2021-12-20 05:37:06", "");
